# RUNNING CVA - CHURAMID V13.10

## Sửa giao diện
- Thanh chọn người quan sát chỉ xuất hiện khi đăng nhập bằng mã quan sát hoặc tài khoản quản trị quan sát.
- Người chơi thường không còn thấy mục “Xem người chơi”.
- Nút `?` hoạt động trên cả máy tính và điện thoại.
- Luật căn trái; phần hướng dẫn không còn nhãn “Tầng 1/2/3” và “MAP 1/2/3”.

## Sửa Map 3
- Một Golem tuần tra rộng quanh nửa phải mê cung và khu vực kho báu.
- Chỉ đuổi khi người chơi tới gần; mất dấu sẽ quay lại tuần tra.
- Tốc độ Golem bằng 60% người chơi.

## Sửa điều khiển
- Bỏ quán tính khiến nhân vật trượt thêm một nhịp khi thả phím.
- Client và server cùng dùng chuyển động trực tiếp, chia bước va chạm giống nhau.
- Gửi input ngay khi nhấn phím thay vì chờ chu kỳ kế tiếp.
- Tách số thứ tự hành động khỏi số thứ tự di chuyển để tránh mất thao tác.
- Nút cảm ứng hỗ trợ pointer độc lập để vừa giữ joystick vừa thao tác.
- Tần suất WebSocket đề xuất tăng từ 15 lên 20 state/giây.
