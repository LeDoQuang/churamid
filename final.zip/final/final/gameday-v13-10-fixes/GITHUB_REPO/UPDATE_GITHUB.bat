@echo off
chcp 65001 >nul
cd /d "%~dp0"
where git >nul 2>nul || (echo Chưa có Git.& pause & exit /b 1)
set /p MSG=Nội dung cập nhật: 
if "%MSG%"=="" set MSG=Cập nhật GAMEDAY 2026
git add .
git commit -m "%MSG%"
git push
pause
