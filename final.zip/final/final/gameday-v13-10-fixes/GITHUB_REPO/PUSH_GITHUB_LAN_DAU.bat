@echo off
chcp 65001 >nul
cd /d "%~dp0"
where git >nul 2>nul || (echo Chưa có Git. Cài Git for Windows trước.& pause & exit /b 1)
set /p REPO=Nhập URL repository, ví dụ https://github.com/tenban/gameday-2026.git: 
if "%REPO%"=="" (echo Chưa nhập URL repository.& pause & exit /b 1)
git init
git branch -M main
git remote remove origin >nul 2>nul
git remote add origin "%REPO%"
git add .
git commit -m "GAMEDAY 2026 - frontend V13.6"
git push -u origin main
if errorlevel 1 (echo Push thất bại. Kiểm tra đăng nhập GitHub hoặc URL repository.& pause & exit /b 1)
echo.
echo Đã push xong. Vào Settings ^> Pages ^> main ^> /docs để bật GitHub Pages.
pause
