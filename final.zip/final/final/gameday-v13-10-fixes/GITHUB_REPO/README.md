# GAMEDAY V13.6 — Frontend GitHub Pages

Up nguyên thư mục `docs` lên repository và chọn GitHub Pages từ nhánh `main`, thư mục `/docs`.

Trước khi chạy chính thức, mở `docs/client-config.js` và điền URL Cloudflare vào `DEFAULT_SERVER_URL`.

Không up `SERVER_LOCAL`, `event.json`, `runtime.json`, `audit.log`, backup hoặc mật khẩu admin lên repository public.
