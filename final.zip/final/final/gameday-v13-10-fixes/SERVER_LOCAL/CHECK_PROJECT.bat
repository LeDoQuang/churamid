@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Chua cai Node.js.& pause & exit /b 1)
node --check server\server.js || goto :fail
node --check server\engine.js || goto :fail
node --check public\game.js || goto :fail
node --check public\login.js || goto :fail
node --check public\admin.js || goto :fail
node --check public\scoreboard.js || goto :fail
node --check public\client-config.js || goto :fail
powershell -NoProfile -Command "$n=(Get-ChildItem '.\public\assets' -File).Count; Write-Host ('Asset: '+$n+' file')"
echo Kiem tra ma nguon thanh cong.
pause
exit /b 0
:fail
echo Co loi ma nguon.
pause
exit /b 1
