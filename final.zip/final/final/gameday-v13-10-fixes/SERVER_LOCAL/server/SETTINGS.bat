@echo off
rem ===== CAU HINH MAY CHU RUNNING CVA - CHURAMID =====
set PORT=3000
set ADMIN_USER=admin
set ADMIN_PASSWORD=cva2026
set ADMIN_REMOTE=0
set WS_FPS=15
rem ADMIN_REMOTE=0: trang admin chi mo tren chinh may chu.
rem DOI ADMIN_PASSWORD truoc khi chay chinh thuc.

rem Cac trang frontend duoc phep ket noi den server.
set ALLOWED_ORIGINS=https://churamidgameday2026.me,https://www.churamidgameday2026.me,https://ledoquang.github.io
