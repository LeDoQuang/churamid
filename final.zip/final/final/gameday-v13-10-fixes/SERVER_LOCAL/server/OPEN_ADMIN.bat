@echo off
cd /d "%~dp0"
call SETTINGS.bat
start "" "http://localhost:%PORT%/admin"
