@echo off
set PORT=3000
set ADMIN_USER=admin
set ADMIN_PASSWORD=DOI_MAT_KHAU_NAY
set ADMIN_REMOTE=0
set WS_FPS=20
set ALLOWED_ORIGINS=https://churamidgameday2026.me,https://www.churamidgameday2026.me,https://ledoquang.github.io
