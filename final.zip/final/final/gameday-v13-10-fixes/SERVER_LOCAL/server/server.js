'use strict';

const http=require('http');
const fs=require('fs');
const path=require('path');
const zlib=require('zlib');
const crypto=require('crypto');
const {URL}=require('url');
const engine=require('./engine');

const PORT=Number(process.env.PORT||3000);
const ROOT=path.join(__dirname,'..','public');
const DATA_DIR=path.join(__dirname,'data');
const DB_FILE=path.join(DATA_DIR,'event.json');
const RUNTIME_FILE=path.join(DATA_DIR,'runtime.json');
const AUDIT_FILE=path.join(DATA_DIR,'audit.log');
const ADMIN_USER=String(process.env.ADMIN_USER||'admin');
const ADMIN_PASSWORD=String(process.env.ADMIN_PASSWORD||'cva2026');
const ADMIN_REMOTE=process.env.ADMIN_REMOTE==='1';
const ALLOWED_ORIGINS=new Set(String(process.env.ALLOWED_ORIGINS||'').split(',').map(v=>v.trim()).filter(Boolean));
const ALLOW_CHEAT=process.env.ALLOW_CHEAT!=='0';
const WS_FPS=Math.max(10,Math.min(24,Number(process.env.WS_FPS||20)));
const SESSION_TTL=12*60*60*1000;
const OBSERVER_TTL=8*60*60*1000;
const LOGIN_WINDOW=5*60*1000;
const LOGIN_LIMIT=8;

fs.mkdirSync(DATA_DIR,{recursive:true});
engine.setAllowCheat(ALLOW_CHEAT);

const now=()=>Date.now();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const cleanText=(v,max=80)=>String(v??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max);
const normalize=(v)=>cleanText(v,80).normalize('NFKC').toLocaleLowerCase('vi-VN');
const safeAccount=(v)=>cleanText(v,32).toLowerCase().replace(/[^a-z0-9._-]/g,'');
const randomToken=(bytes=32)=>crypto.randomBytes(bytes).toString('base64url');
const formatMs=(ms)=>{const s=Math.max(0,Math.floor((Number(ms)||0)/1000));return`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`};

function passwordHash(password,salt=randomToken(16)){
  const hash=crypto.scryptSync(String(password),salt,32,{N:16384,r:8,p:1}).toString('hex');
  return `scrypt$${salt}$${hash}`;
}
function passwordVerify(password,stored){
  return new Promise(resolve=>{
    try{
      const [kind,salt,hex]=String(stored||'').split('$');
      if(kind!=='scrypt'||!salt||!hex)return resolve(false);
      const expected=Buffer.from(hex,'hex');
      crypto.scrypt(String(password),salt,32,{N:16384,r:8,p:1},(err,got)=>{
        if(err||got.length!==expected.length)return resolve(false);
        resolve(crypto.timingSafeEqual(got,expected));
      });
    }catch{resolve(false)}
  });
}
function atomicWrite(file,obj){
  const tmp=`${file}.tmp`;
  fs.writeFileSync(tmp,JSON.stringify(obj,null,2),'utf8');
  fs.renameSync(tmp,file);
}
function audit(action,detail={}){
  const row={time:new Date().toISOString(),action,...detail};
  fs.appendFile(AUDIT_FILE,JSON.stringify(row)+'\n',()=>{});
}

function defaultDb(){
  return {
    version:3,
    event:{name:'IDEA GAMEDAY 2026',status:'registration',createdAt:now(),startedAt:null,endedAt:null,pausedAt:null,totalPausedMs:0},
    teams:[{
      id:'demo',name:'Đội thử nghiệm',account:'demo',passwordHash:passwordHash('demo123'),observerCode:'watch-demo',
      players:[],playerJoinedAt:[],rosterLocked:false,createdAt:now(),disabled:false,
      completionMs:null,finishedAt:null,lastResetAt:null
    }]
  };
}
function loadJson(file,fallback){try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch{return fallback}}
let db=loadJson(DB_FILE,null)||defaultDb();
if(!Array.isArray(db.teams))db.teams=[];
if(!db.event)db.event=defaultDb().event;
db.version=3;
for(const team of db.teams){
  const old=Array.isArray(team.players)?team.players.map(v=>cleanText(v,40)).slice(0,4):[];
  const generic=old.length===4&&old.every((v,i)=>normalize(v)===normalize(`Người chơi ${i+1}`)||v===String(i+1));
  team.players=generic?[]:old;
  team.playerJoinedAt=Array.from({length:4},(_,i)=>Number(team.playerJoinedAt?.[i]||0));
  team.rosterLocked=!!team.rosterLocked;
}
atomicWrite(DB_FILE,db);
const runtimeSaved=loadJson(RUNTIME_FILE,{rooms:{}});

const rooms=new Map();
function sanitizeRestoredGame(g,team){
  if(!g||!Array.isArray(g.players)||g.players.length!==4)return null;
  if(team.players.filter(Boolean).length<3&&g.phase!=='lobby')return null;
  g.teamId=team.id;
  g.players.forEach((p,i)=>{
    const name=team.players[i]||'';
    p.displayName=name||`Vị trí ${i+1}`;p.active=!!name;
    p.connected=false;p.ready=!!p.ready&&p.active;p.lastSeen=0;p.clientToken='';p.lastInputAt=0;p.lastInputSeq=0;p.lastActionSeq=0;p.needsNeutral=true;
    p.input={up:false,down:false,left:false,right:false};p.actions=[];p.vx=0;p.vy=0;if(!p.active)p.escaped=false;
  });
  g.stageAcks=Array.isArray(g.stageAcks)?g.stageAcks.slice(0,4):[false,false,false,false];
  g.events=[[],[],[],[]];
  return g;
}
function createRoom(team){
  const restored=sanitizeRestoredGame(runtimeSaved.rooms?.[team.id],team);
  const game=restored||engine.createGame(team.players,team.id);engine.setActivePlayers(game,team.players);
  const restoredActive=!!restored&&!['lobby','done'].includes(game.phase);const room={teamId:team.id,game,lastPhase:game.phase,lastStage:game.stage,lastTouched:now(),disconnectSince:restoredActive?now()-5000:0,connectionPaused:restoredActive,resumeAt:0};
  rooms.set(team.id,room);return room;
}
for(const team of db.teams)createRoom(team);
function roomForTeam(id){const team=db.teams.find(t=>t.id===id&&!t.disabled);if(!team)return null;return rooms.get(id)||createRoom(team)}
function saveDb(){atomicWrite(DB_FILE,db)}
function runtimeSnapshot(){
  const snapshot={savedAt:now(),rooms:{}};
  for(const [id,room] of rooms)snapshot.rooms[id]=room.game;
  return snapshot;
}
function saveRuntime(){atomicWrite(RUNTIME_FILE,runtimeSnapshot())}
let runtimeSaving=false,runtimeQueued=false;
async function saveRuntimeAsync(){
  if(runtimeSaving){runtimeQueued=true;return}
  runtimeSaving=true;
  try{
    const tmp=`${RUNTIME_FILE}.tmp`,body=JSON.stringify(runtimeSnapshot());
    await fs.promises.writeFile(tmp,body,'utf8');
    await fs.promises.rename(tmp,RUNTIME_FILE);
  }catch(e){console.error('Runtime save:',e.message)}
  finally{runtimeSaving=false;if(runtimeQueued){runtimeQueued=false;setImmediate(saveRuntimeAsync)}}
}
setInterval(saveRuntimeAsync,10000).unref();
let eventLoopLagMs=0,lastLagProbe=now();
setInterval(()=>{const t=now();eventLoopLagMs=Math.max(0,t-lastLagProbe-1000);lastLagProbe=t},1000).unref();
for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>{try{saveRuntime();saveDb()}catch{}process.exit(0)});

const sessions=new Map();
const activePlayerSession=new Map();
const loginAttempts=new Map();
function sessionToken(req,url){
  const auth=String(req.headers.authorization||'');
  if(auth.startsWith('Bearer '))return auth.slice(7).trim();
  return String(req.headers['x-session-token']||url?.searchParams?.get('session')||'').trim();
}
function newSession(data,ttl=SESSION_TTL){
  const token=randomToken(32);const session={token,...data,createdAt:now(),lastSeen:now(),expiresAt:now()+ttl};sessions.set(token,session);return session;
}
function getSession(req,url,roles=[]){
  const token=sessionToken(req,url);const s=sessions.get(token);
  if(!s||s.expiresAt<now()){if(token)sessions.delete(token);return null}
  if(roles.length&&!roles.includes(s.role))return null;
  s.lastSeen=now();s.expiresAt=Math.max(s.expiresAt,now()+30*60*1000);return s;
}
function revokeSession(token){
  const s=sessions.get(token);if(!s)return;
  sessions.delete(token);
  if(s.role==='player'&&activePlayerSession.get(`${s.teamId}:${s.playerId}`)===token)activePlayerSession.delete(`${s.teamId}:${s.playerId}`);
  for(const client of wsClients.values())if(client.sessionToken===token)wsClose(client,1008,'Session ended');
}
function clientIp(req){return String(req.headers['cf-connecting-ip']||req.socket.remoteAddress||'').split(',')[0].trim()}
function isLocal(req){
  if(req.headers['cf-connecting-ip']||req.headers['cf-ray']||req.headers['x-forwarded-for'])return false;
  const ip=String(req.socket.remoteAddress||'');return ip==='127.0.0.1'||ip==='::1'||ip==='::ffff:127.0.0.1';
}
function checkLoginLimit(req,key){
  const k=`${clientIp(req)}:${normalize(key)}`;const t=now();let a=loginAttempts.get(k)||[];a=a.filter(x=>t-x<LOGIN_WINDOW);if(a.length>=LOGIN_LIMIT)return false;a.push(t);loginAttempts.set(k,a);return true;
}
function clearLoginLimit(req,key){loginAttempts.delete(`${clientIp(req)}:${normalize(key)}`)}
setInterval(()=>{const t=now();for(const [k,a] of loginAttempts)if(!a.some(x=>t-x<LOGIN_WINDOW))loginAttempts.delete(k);for(const [token,s] of sessions)if(s.expiresAt<t)revokeSession(token)},60000).unref();

function findTeamByAccount(account){const a=normalize(account);return db.teams.find(t=>normalize(t.account)===a&&!t.disabled)}
function findTeamByObserverCode(code){const c=normalize(code);return c?db.teams.find(t=>normalize(t.observerCode)===c&&!t.disabled):null}
function codeInUse(code,exceptId=''){const c=normalize(code);return !!c&&db.teams.some(t=>t.id!==exceptId&&(normalize(t.account)===c||normalize(t.observerCode)===c));}
function teamSummary(team){
  const room=rooms.get(team.id);const g=room?.game;const playerCount=team.players.filter(Boolean).length;
  const playerDetails=Array.from({length:4},(_,i)=>{const p=g?.players?.[i];return{id:i+1,name:team.players[i]||'',online:!!(p?.active&&p.connected&&now()-p.lastSeen<engine.PLAYER_TIMEOUT),ready:!!p?.ready,lastSeenAt:p?.lastSeen||0};});
  const online=playerDetails.filter(p=>p.name&&p.online).length,ready=playerDetails.filter(p=>p.name&&p.online&&p.ready).length;
  let status='Chưa tham gia';
  if(team.disabled)status='Đã khóa';
  else if(team.completionMs!=null||g?.phase==='done')status='Hoàn thành';
  else if(db.event.status==='ended')status='Sự kiện đã kết thúc';
  else if(db.event.status==='paused')status='Đang tạm dừng';
  else if(room?.connectionPaused)status=room.resumeAt?`Kết nối lại · tiếp tục sau ${Math.max(1,Math.ceil((room.resumeAt-now())/1000))} giây`:'Đang chờ thành viên kết nối lại';
  else if(g?.phase==='lobby')status=playerCount?`Phòng chờ ${playerCount}/4 thành viên`:'Chưa tham gia';
  else if(g?.phase==='briefing')status=`Hướng dẫn tầng ${g.stage}`;
  else if(g?.phase==='countdown')status=`Chuẩn bị tầng ${g.stage}`;
  else if(g?.phase==='playing')status=`Đang chơi tầng ${g.stage}`;
  else if(g?.phase==='resetting')status=`Đang chơi tầng ${g.stage} · vừa reset`;
  return {id:team.id,name:team.name,account:team.account,players:team.players,playerDetails,playerCount,rosterLocked:!!team.rosterLocked,observerCode:team.observerCode,disabled:!!team.disabled,online,ready,status,stage:g?.stage||0,phase:g?.phase||'lobby',connectionPaused:!!room?.connectionPaused,elapsedMs:Math.round((g?.totalElapsed||0)*1000),elapsedText:formatMs((g?.totalElapsed||0)*1000),completionMs:team.completionMs,completionText:team.completionMs==null?'—':formatMs(team.completionMs),finishedAt:team.finishedAt,createdAt:team.createdAt};
}
function publicEvent(){return {name:db.event.name,status:db.event.status,startedAt:db.event.startedAt,endedAt:db.event.endedAt,serverTime:now()}}
function persistTeamCompletion(team,room){
  if(room.game.phase==='done'&&team.completionMs==null){team.completionMs=Math.round(room.game.totalElapsed*1000);team.finishedAt=now();room.game.finishedAt=team.finishedAt;saveDb();audit('team.finish',{teamId:team.id,timeMs:team.completionMs});}
}

function roomOnlineCount(room){return room.game.players.filter(p=>p.active&&p.connected&&now()-p.lastSeen<engine.PLAYER_TIMEOUT).length;}
function updateConnectionPause(room,team,t){
  const g=room.game,active=team.players.filter(Boolean).length,needed=Math.min(3,active);
  if(['lobby','done'].includes(g.phase)||needed<3){room.disconnectSince=0;room.connectionPaused=false;room.resumeAt=0;return;}
  const online=roomOnlineCount(room);
  if(online<needed){room.resumeAt=0;if(!room.disconnectSince)room.disconnectSince=t;if(t-room.disconnectSince>=5000)room.connectionPaused=true;return;}
  room.disconnectSince=0;
  if(room.connectionPaused&&!room.resumeAt)room.resumeAt=t+3000;
  if(room.connectionPaused&&room.resumeAt&&t>=room.resumeAt){room.connectionPaused=false;room.resumeAt=0;}
}
let lastTick=now();
setInterval(()=>{
  const t=now(),dt=Math.min(.05,(t-lastTick)/1000);lastTick=t;let dbDirty=false;
  for(const team of db.teams){
    if(team.disabled)continue;
    const room=roomForTeam(team.id);if(!room)continue;
    updateConnectionPause(room,team,t);
    const run=db.event.status==='running'&&!room.connectionPaused;
    engine.tickGame(room.game,dt,run);
    if(room.lastPhase==='lobby'&&room.game.phase!=='lobby'){team.rosterLocked=true;dbDirty=true;audit('team.ready_start',{teamId:team.id,players:team.players.filter(Boolean).length});}
    persistTeamCompletion(team,room);
    room.lastPhase=room.game.phase;room.lastStage=room.game.stage;
  }
  if(dbDirty)saveDb();
},1000/30);

function wsFrame(opcode,payload=Buffer.alloc(0)){
  const data=Buffer.isBuffer(payload)?payload:Buffer.from(String(payload));const length=data.length;let header;
  if(length<126){header=Buffer.allocUnsafe(2);header[0]=0x80|opcode;header[1]=length}
  else if(length<=0xffff){header=Buffer.allocUnsafe(4);header[0]=0x80|opcode;header[1]=126;header.writeUInt16BE(length,2)}
  else{header=Buffer.allocUnsafe(10);header[0]=0x80|opcode;header[1]=127;header.writeBigUInt64BE(BigInt(length),2)}
  return Buffer.concat([header,data]);
}
function wsSend(client,value){if(!client||client.closed||client.socket.destroyed||!client.socket.writable)return false;try{return client.socket.write(wsFrame(1,typeof value==='string'?value:JSON.stringify(value)))}catch{return false}}
function wsClose(client,code=1000,reason=''){if(!client||client.closed)return;client.closed=true;try{const r=Buffer.from(String(reason).slice(0,100));const p=Buffer.allocUnsafe(2+r.length);p.writeUInt16BE(code,0);r.copy(p,2);client.socket.write(wsFrame(8,p))}catch{}try{client.socket.end()}catch{}}
const wsClients=new Map();
function claimPlayer(room,session){
  const p=room.game.players[session.playerId-1];
  if(!p||!p.active)return null;
  if(p.clientToken!==session.token){
    p.clientToken=session.token;
    p.lastInputSeq=0;p.lastActionSeq=0;
    p.input={up:false,down:false,left:false,right:false};p.actions.length=0;
    p.vx=0;p.vy=0;p.needsNeutral=true;
  }
  p.connected=true;p.lastSeen=now();return p;
}
function stateForSession(s,includeStatic=true,viewPlayer=null){
  const team=db.teams.find(t=>t.id===s.teamId);const room=roomForTeam(s.teamId);if(!team||!room)return null;
  const observer=s.role!=='player';const pid=observer?clamp(Number(viewPlayer||s.viewPlayer||1),1,4):s.playerId;
  const state=engine.getPublicState(room.game,pid,includeStatic,{observer,team:{id:team.id,name:team.name,players:team.players,playerCount:team.players.filter(Boolean).length},event:publicEvent()});
  state.connectionPause={paused:!!room.connectionPaused,resumeIn:room.resumeAt?Math.max(0,(room.resumeAt-now())/1000):0,online:roomOnlineCount(room),needed:Math.min(3,team.players.filter(Boolean).length)};
  return state;
}
function parseWsFrames(client,chunk){
  client.buffer=Buffer.concat([client.buffer,chunk]);
  while(client.buffer.length>=2){
    const b0=client.buffer[0],b1=client.buffer[1],fin=!!(b0&0x80),opcode=b0&15,masked=!!(b1&0x80);let length=b1&127,offset=2;
    if(length===126){if(client.buffer.length<4)return;length=client.buffer.readUInt16BE(2);offset=4}else if(length===127){if(client.buffer.length<10)return;const n=client.buffer.readBigUInt64BE(2);if(n>BigInt(1_000_000)){wsClose(client,1009,'Payload too large');return}length=Number(n);offset=10}
    if(!masked||!fin){wsClose(client,1002,'Invalid frame');return}if(client.buffer.length<offset+4+length)return;
    const mask=client.buffer.subarray(offset,offset+4);offset+=4;const payload=Buffer.from(client.buffer.subarray(offset,offset+length));client.buffer=client.buffer.subarray(offset+length);for(let i=0;i<payload.length;i++)payload[i]^=mask[i&3];
    if(opcode===8){wsClose(client);return}if(opcode===9){client.lastPong=now();try{client.socket.write(wsFrame(10,payload))}catch{}continue}if(opcode===10){client.lastPong=now();continue}if(opcode!==1)continue;
    try{
      const mt=now();if(mt-(client.msgWindow||0)>1000){client.msgWindow=mt;client.msgCount=0}client.msgCount=(client.msgCount||0)+1;if(client.msgCount>120){wsClose(client,1008,'Too many messages');return}
      const msg=JSON.parse(payload.toString('utf8'));const s=sessions.get(client.sessionToken);if(!s||s.expiresAt<now()){wsClose(client,1008,'Session expired');return}
      s.lastSeen=now();
      if(msg.type==='ping'){wsSend(client,{type:'pong',t:msg.t||now()});continue}
      if(s.role==='observer'||s.role==='admin-observer'){if(msg.type==='view'){client.viewPlayer=clamp(Number(msg.player)||1,1,4)}continue}
      const room=roomForTeam(s.teamId);if(!room)continue;const p=claimPlayer(room,s);if(!p)continue;
      if(db.event.status!=='running')continue;
      if(msg.type==='input')engine.applyInput(room.game,s.playerId,msg);else if(msg.type==='action')engine.applyAction(room.game,s.playerId,msg);
    }catch{}
  }
}
function handleWsUpgrade(req,socket,head){
  let url;try{url=new URL(req.url,'http://localhost')}catch{socket.destroy();return}
  if(url.pathname!=='/ws'){socket.destroy();return}
  const origin=String(req.headers.origin||'');
  if(origin&&!originAllowed(req)){socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');socket.destroy();return}
  const token=String(url.searchParams.get('session')||'');const s=sessions.get(token);
  if(!s||s.expiresAt<now()){socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');socket.destroy();return}
  const team=db.teams.find(t=>t.id===s.teamId&&!t.disabled);const room=roomForTeam(s.teamId);if(!team||!room){socket.destroy();return}
  const key=req.headers['sec-websocket-key'];if(!key||String(req.headers.upgrade||'').toLowerCase()!=='websocket'){socket.destroy();return}
  const accept=crypto.createHash('sha1').update(String(key)+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');socket.setNoDelay(true);socket.setKeepAlive(true,15000);
  if(s.role==='player'){
    const old=[...wsClients.values()].find(c=>c.sessionToken===token&&!c.closed);if(old)wsClose(old,1000,'Replaced');claimPlayer(room,s);
  }
  const id=randomToken(12);const client={id,sessionToken:token,teamId:s.teamId,role:s.role,playerId:s.playerId||1,viewPlayer:clamp(Number(url.searchParams.get('view')||s.playerId||1),1,4),socket,buffer:Buffer.alloc(0),closed:false,blocked:false,staticKey:'',lastSent:0,lastPong:now(),msgWindow:now(),msgCount:0};wsClients.set(id,client);
  const close=()=>{if(client.closed&&wsClients.get(id)!==client)return;client.closed=true;wsClients.delete(id);if(s.role==='player'){const p=room.game.players[s.playerId-1];if(p&&p.clientToken===token){p.connected=false;p.input={up:false,down:false,left:false,right:false};p.vx=0;p.vy=0;p.needsNeutral=true}}};
  socket.on('data',c=>parseWsFrames(client,c));socket.on('close',close);socket.on('end',close);socket.on('error',close);socket.on('drain',()=>client.blocked=false);if(head?.length)parseWsFrames(client,head);
  const state=stateForSession(s,true,client.viewPlayer);if(state)wsSend(client,{type:'state',data:state});
}
setInterval(()=>{
  for(const [id,c] of wsClients){
    if(c.closed||c.socket.destroyed){wsClients.delete(id);continue}const s=sessions.get(c.sessionToken);if(!s||s.expiresAt<now()){wsClose(c,1008,'Session expired');wsClients.delete(id);continue}
    const room=roomForTeam(s.teamId);if(!room){wsClose(c,1008,'Room removed');continue}
    if(s.role==='player')claimPlayer(room,s);if(c.blocked)continue;
    const interval=room.game.phase==='playing'?1000/WS_FPS:room.game.phase==='briefing'||room.game.phase==='countdown'?100:250;
    const ts=now();if(ts-c.lastSent<interval)continue;c.lastSent=ts;
    const key=`${room.game.stage}:${room.game.stage===1?(room.game.map1?.puzzleIndex??0):0}`;
    const includeStatic=c.staticKey!==key;const state=stateForSession(s,includeStatic,c.viewPlayer);if(!state)continue;const ok=wsSend(c,{type:'state',data:state});if(ok&&includeStatic)c.staticKey=key;else if(!ok)c.blocked=true;
  }
},1000/WS_FPS);
setInterval(()=>{
  const t=now();
  for(const [id,c] of wsClients){
    if(c.closed||c.socket.destroyed){wsClients.delete(id);continue}
    if(t-(c.lastPong||c.lastSent||t)>60000){wsClose(c,1001,'Connection timeout');wsClients.delete(id);continue}
    try{c.socket.write(wsFrame(9,Buffer.from('hb')))}catch{wsClose(c,1001,'Connection error')}
  }
},20000).unref();

function originAllowed(req){
  const origin=String(req.headers.origin||'');if(!origin)return true;
  try{const u=new URL(origin);if(u.host===String(req.headers.host||''))return true;}catch{return false}
  return ALLOWED_ORIGINS.has(origin);
}
function markCors(req,res){const origin=String(req.headers.origin||'');if(origin&&originAllowed(req))res._corsOrigin=origin;}
function corsHeaders(res){return res?._corsOrigin?{'Access-Control-Allow-Origin':res._corsOrigin,'Vary':'Origin'}:{}}
function securityHeaders(){return {'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Cross-Origin-Opener-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"}}
function sendJson(res,code,obj){const body=JSON.stringify(obj);res.writeHead(code,{...securityHeaders(),...corsHeaders(res),'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Content-Length':Buffer.byteLength(body)});res.end(body)}
function readBody(req,max=32768){return new Promise((resolve,reject)=>{let data='',done=false;req.on('data',c=>{if(done)return;data+=c;if(Buffer.byteLength(data)>max){done=true;const e=new Error('Payload too large');e.statusCode=413;reject(e);req.destroy()}});req.on('end',()=>{if(done)return;try{resolve(data?JSON.parse(data):{})}catch(e){e.statusCode=400;reject(e)}});req.on('error',reject)})}
function mime(file){return ({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.json':'application/json','.md':'text/markdown; charset=utf-8','.txt':'text/plain; charset=utf-8','.webmanifest':'application/manifest+json'})[path.extname(file).toLowerCase()]||'application/octet-stream'}
function serveStatic(req,res,urlPath){
  let rel=urlPath;if(rel==='/')rel='/index.html';if(rel==='/game')rel='/game.html';if(rel==='/admin')rel='/admin.html';if(rel==='/scoreboard')rel='/scoreboard.html';
  let decoded;try{decoded=decodeURIComponent(rel)}catch{return sendJson(res,400,{ok:false,message:'Đường dẫn không hợp lệ.'})}
  const file=path.resolve(ROOT,'.'+decoded),relative=path.relative(ROOT,file);if(relative.startsWith('..')||path.isAbsolute(relative))return sendJson(res,403,{ok:false,message:'Forbidden'});
  if((relative==='admin.html'||relative==='admin.js'||relative==='admin.css')&&!ADMIN_REMOTE&&!isLocal(req))return sendJson(res,403,{ok:false,message:'Trang quản trị chỉ mở được trên máy chủ.'});
  fs.stat(file,(e,st)=>{if(e||!st.isFile()){res.writeHead(404,{...securityHeaders(),'Content-Type':'text/plain; charset=utf-8'});return res.end('Not found')};const etag=`W/\"${st.size}-${Math.floor(st.mtimeMs)}\"`;if(req.headers['if-none-match']===etag){res.writeHead(304,{...securityHeaders(),ETag:etag});return res.end()};fs.readFile(file,(err,data)=>{if(err)return sendJson(res,500,{ok:false});const ext=path.extname(file).toLowerCase(),asset=relative.startsWith(`assets${path.sep}`),text=['.html','.js','.css','.json','.webmanifest','.md','.txt'].includes(ext);const headers={...securityHeaders(),'Content-Type':mime(file),ETag:etag,'Vary':'Accept-Encoding','Cache-Control':asset?'public,max-age=86400,immutable':'no-cache'};if(text&&/\bgzip\b/.test(req.headers['accept-encoding']||''))zlib.gzip(data,{level:6},(ze,z)=>{const b=ze?data:z;res.writeHead(200,{...headers,...(!ze?{'Content-Encoding':'gzip'}:{}),'Content-Length':b.length});res.end(b)});else{res.writeHead(200,{...headers,'Content-Length':data.length});res.end(data)}})});
}
function requireAdmin(req,res,url){if(!ADMIN_REMOTE&&!isLocal(req)){sendJson(res,403,{ok:false,message:'Quản trị chỉ được phép trên máy chủ.'});return null}const s=getSession(req,url,['admin']);if(!s)sendJson(res,401,{ok:false,message:'Phiên quản trị không hợp lệ.'});return s}
function preparePlayerNames(names,current=[]){const result=Array.from({length:4},(_,i)=>cleanText(names?.[i]||current?.[i]||'',40));const used=result.filter(Boolean);if(new Set(used.map(normalize)).size!==used.length)return null;return result}
function updateTeamPlayerNames(team,names){const prepared=preparePlayerNames(names,team.players);if(!prepared)return false;team.players=prepared;const room=rooms.get(team.id);if(room)room.game.players.forEach((p,i)=>p.displayName=team.players[i]);return true}
function compactLobbyRoster(team){
  const room=rooms.get(team.id);if(!room||room.game.phase!=='lobby')return;
  const previous=new Map();
  for(const p of room.game.players){
    if(!p.active||!p.displayName)continue;
    previous.set(normalize(p.displayName),{
      connected:!!p.connected&&now()-p.lastSeen<engine.PLAYER_TIMEOUT,
      ready:!!p.ready,lastSeen:Number(p.lastSeen||0),clientToken:String(p.clientToken||'')
    });
  }
  const entries=Array.from({length:4},(_,i)=>team.players[i]?{name:team.players[i],joinedAt:Number(team.playerJoinedAt?.[i]||now())}:null).filter(Boolean);
  team.players=Array.from({length:4},(_,i)=>entries[i]?.name||'');team.playerJoinedAt=Array.from({length:4},(_,i)=>entries[i]?.joinedAt||0);
  for(const key of [...activePlayerSession.keys()])if(key.startsWith(`${team.id}:`))activePlayerSession.delete(key);
  engine.resetGame(room.game);engine.setActivePlayers(room.game,team.players);
  room.game.players.forEach((p,i)=>{
    const old=previous.get(normalize(team.players[i]||''));if(!old)return;
    p.connected=old.connected;p.ready=old.ready&&old.connected;p.lastSeen=old.lastSeen;p.clientToken=old.connected?old.clientToken:'';
  });
  for(const [tok,s] of [...sessions]){
    if(s.teamId!==team.id||s.role!=='player')continue;
    const idx=team.players.findIndex(n=>normalize(n)===normalize(s.displayName));
    if(idx<0){revokeSession(tok);continue}
    s.playerId=idx+1;activePlayerSession.set(`${team.id}:${idx+1}`,tok);
  }
  for(const c of wsClients.values()){
    const ss=sessions.get(c.sessionToken);if(ss?.teamId!==team.id||ss.role!=='player')continue;
    c.playerId=ss.playerId;const p=room.game.players[ss.playerId-1];if(p){p.connected=true;p.lastSeen=now();p.clientToken=ss.token;}
  }
}
function removePlayerSlot(team,index,reason='admin',compact=true){
  index=clamp(Number(index)||0,0,3);const name=team.players[index];if(!name)return false;
  const room=rooms.get(team.id);for(const [tok,s] of [...sessions])if(s.teamId===team.id&&s.role==='player'&&s.playerId===index+1)revokeSession(tok);
  activePlayerSession.delete(`${team.id}:${index+1}`);team.players[index]='';team.playerJoinedAt[index]=0;
  if(room){const p=room.game.players[index];if(p){p.connected=false;p.ready=false;p.clientToken='';p.input={up:false,down:false,left:false,right:false};p.actions=[];p.vx=0;p.vy=0;}engine.setActivePlayers(room.game,team.players);if(compact&&room.game.phase==='lobby')compactLobbyRoster(team);}
  audit('team.player_remove',{teamId:team.id,playerId:index+1,name,reason});return true;
}
function prepareImmediateStart(team,room){
  const onlineIndices=room.game.players.map((p,i)=>p.active&&p.connected&&now()-p.lastSeen<engine.PLAYER_TIMEOUT?i:-1).filter(i=>i>=0);
  if(onlineIndices.length<3)return{ok:false,message:'Cần ít nhất 3 thành viên đang trực tuyến để bắt đầu đội.'};
  const onlineSet=new Set(onlineIndices);
  const offline=[];for(let i=0;i<4;i++)if(team.players[i]&&!onlineSet.has(i))offline.push(i);
  for(const i of offline.sort((a,b)=>b-a))removePlayerSlot(team,i,'force_start_offline',false);
  if(offline.length)compactLobbyRoster(team);
  const online=roomOnlineCount(room);if(online<3)return{ok:false,message:'Cần ít nhất 3 thành viên đang trực tuyến để bắt đầu đội.'};
  team.rosterLocked=true;engine.setActivePlayers(room.game,team.players);engine.forceStart(room.game,1);
  team.completionMs=null;team.finishedAt=null;room.connectionPaused=false;room.disconnectSince=0;room.resumeAt=0;
  return{ok:true,players:team.players.filter(Boolean).length};
}

function tryCoordinatedStart(team,room){
  if(db.event.status!=='running'||room.game.phase!=='lobby')return{ok:true,started:false};
  const t=now();
  const onlineIndices=room.game.players
    .map((p,i)=>p.active&&p.connected&&t-p.lastSeen<engine.PLAYER_TIMEOUT?i:-1)
    .filter(i=>i>=0);
  if(onlineIndices.length<3)return{ok:true,started:false,online:onlineIndices.length,ready:onlineIndices.filter(i=>room.game.players[i].ready).length};
  const readyIndices=onlineIndices.filter(i=>room.game.players[i].ready);
  if(readyIndices.length!==onlineIndices.length)return{ok:true,started:false,online:onlineIndices.length,ready:readyIndices.length};

  // Khi 3/3 hoặc 4/4 người đang online đã bấm Bắt đầu, khóa đúng đội hình đó.
  // Thành viên đã rời sảnh không được giữ một vị trí ảo làm đội bị kẹt.
  const onlineSet=new Set(onlineIndices);
  const offline=[];
  for(let i=0;i<4;i++)if(team.players[i]&&!onlineSet.has(i))offline.push(i);
  for(const i of offline.sort((a,b)=>b-a))removePlayerSlot(team,i,'ready_start_offline',false);
  if(offline.length)compactLobbyRoster(team);

  const finalOnline=roomOnlineCount(room);
  if(finalOnline<3)return{ok:true,started:false,online:finalOnline,ready:0};
  team.rosterLocked=true;
  engine.setActivePlayers(room.game,team.players);
  engine.forceStart(room.game,1);
  team.completionMs=null;team.finishedAt=null;
  room.connectionPaused=false;room.disconnectSince=0;room.resumeAt=0;
  audit('team.coordinated_start',{teamId:team.id,players:finalOnline});
  return{ok:true,started:true,players:finalOnline};
}

function cleanupLobbyGhosts(){
  const t=now();let changed=false;
  for(const team of db.teams){const room=rooms.get(team.id);if(!room||room.game.phase!=='lobby'||team.rosterLocked)continue;const grace=db.event.status==='running'?90000:300000;const remove=[];
    for(let i=0;i<4;i++){const p=room.game.players[i],joined=Number(team.playerJoinedAt?.[i]||0);if(!team.players[i]||p?.connected)continue;const last=Math.max(joined,p?.lastSeen||0);if(last&&t-last>grace)remove.push(i);}
    for(const i of remove.sort((a,b)=>b-a)){removePlayerSlot(team,i,'offline_timeout',false);changed=true;}if(remove.length)compactLobbyRoster(team);
  }
  if(changed)saveDb();
}

setInterval(cleanupLobbyGhosts,15000).unref();


function parseCsv(text){
  const rows=[];let row=[],cell='',quoted=false;const src=String(text||'').replace(/^\ufeff/,'');
  for(let i=0;i<src.length;i++){
    const ch=src[i];
    if(quoted){if(ch==='"'&&src[i+1]==='"'){cell+='"';i++}else if(ch==='"')quoted=false;else cell+=ch;continue}
    if(ch==='"'){quoted=true;continue}
    if(ch===','){row.push(cell.trim());cell='';continue}
    if(ch==='\n'){row.push(cell.trim());if(row.some(Boolean))rows.push(row);row=[];cell='';continue}
    if(ch!=='\r')cell+=ch;
  }
  row.push(cell.trim());if(row.some(Boolean))rows.push(row);return rows;
}
function importTeamsCsv(csv){
  const rows=parseCsv(csv);if(!rows.length)return{imported:0,errors:['Tệp CSV trống.']};
  const first=rows[0].map(normalize),hasHeader=first.some(v=>['account','tai khoan','tài khoản','mã đội chơi','ma doi choi','team_account'].includes(v));
  const data=hasHeader?rows.slice(1):rows;let imported=0;const errors=[];
  data.forEach((r,index)=>{
    const line=index+(hasHeader?2:1);const [nameRaw,accountRaw,password,...rest]=r;const observerRaw=rest.length>=5?rest[4]:rest[0];
    const name=cleanText(nameRaw,60),account=safeAccount(accountRaw);
    if(!name||!account||String(password||'').length<6){errors.push(`Dòng ${line}: thiếu tên đội, mã đội chơi hoặc mật khẩu dưới 6 ký tự.`);return}
    if(codeInUse(account)){errors.push(`Dòng ${line}: mã đội ${account} đã tồn tại hoặc trùng mã quan sát.`);return}
    let id=account;while(db.teams.some(t=>t.id===id))id=`${account}-${Math.floor(Math.random()*999)+1}`;
    const observerCode=cleanText(observerRaw||randomToken(6),32);if(codeInUse(observerCode)){errors.push(`Dòng ${line}: mã quan sát ${observerCode} đã tồn tại hoặc trùng mã đội chơi.`);return}const team={id,name,account,passwordHash:passwordHash(password),observerCode,players:[],playerJoinedAt:[],rosterLocked:false,createdAt:now(),disabled:false,completionMs:null,finishedAt:null};
    db.teams.push(team);createRoom(team);imported++;
  });
  if(imported)saveDb();return{imported,errors};
}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost');markCors(req,res);
    if(req.headers.origin&&!originAllowed(req)&&url.pathname.startsWith('/api/'))return sendJson(res,403,{ok:false,message:'Origin không được phép.'});
    if(req.method==='OPTIONS'){res.writeHead(204,{...securityHeaders(),...corsHeaders(res),'Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,X-Session-Token,Authorization'});return res.end()}
    if(url.pathname==='/health'&&req.method==='GET')return sendJson(res,200,{ok:true,version:'V13.10',event:publicEvent(),teams:db.teams.filter(t=>!t.disabled).length,websocket:true,wsClients:wsClients.size,memoryMb:Math.round(process.memoryUsage().rss/1048576),eventLoopLagMs:Math.round(eventLoopLagMs)});
    if(url.pathname==='/api/public/event'&&req.method==='GET')return sendJson(res,200,{ok:true,event:publicEvent()});
    if(url.pathname==='/api/public/scoreboard'&&req.method==='GET'){
      const ranked=db.teams.filter(t=>!t.disabled).map(teamSummary).sort((a,b)=>{
        if(a.completionMs!=null&&b.completionMs!=null)return a.completionMs-b.completionMs;
        if(a.completionMs!=null)return-1;if(b.completionMs!=null)return 1;
        if(a.stage!==b.stage)return b.stage-a.stage;return b.elapsedMs-a.elapsedMs;
      }).map((t,i)=>({rank:t.completionMs!=null?i+1:null,id:t.id,name:t.name,status:t.status,stage:t.stage,online:t.online,playerCount:t.playerCount,completionMs:t.completionMs,completionText:t.completionText,elapsedText:t.elapsedText,finishedAt:t.finishedAt}));
      return sendJson(res,200,{ok:true,event:publicEvent(),teams:ranked});
    }

    if(url.pathname==='/api/auth/team'&&req.method==='POST'){
      const b=await readBody(req),loginCode=cleanText(b.account,40);if(!checkLoginLimit(req,loginCode))return sendJson(res,429,{ok:false,message:'Đăng nhập sai quá nhiều. Chờ vài phút rồi thử lại.'});
      const team=findTeamByAccount(loginCode);if(!team)return sendJson(res,401,{ok:false,message:'Mã đội chơi hoặc mật khẩu không đúng.'});
      const secret=String(b.password||'');
      if(normalize(secret)===normalize(team.observerCode)){
        clearLoginLimit(req,loginCode);const os=newSession({role:'observer',teamId:team.id,viewPlayer:1},OBSERVER_TTL);audit('login.observer',{teamId:team.id,ip:clientIp(req)});return sendJson(res,200,{ok:true,session:os.token,profile:{role:'observer',teamId:team.id,teamName:team.name,playerId:1,playerName:'Người quan sát',players:team.players},event:publicEvent()});
      }
      if(!await passwordVerify(secret,team.passwordHash))return sendJson(res,401,{ok:false,message:'Mã đội chơi hoặc mật khẩu không đúng.'});
      const playerName=cleanText(b.playerName,40);if(playerName.length<2)return sendJson(res,400,{ok:false,message:'Hãy nhập tên người chơi ít nhất 2 ký tự.'});
      const room=roomForTeam(team.id);const wanted=normalize(playerName);let idx=team.players.findIndex(n=>normalize(n)===wanted);
      if(idx<0){
        if(team.rosterLocked||room.game.phase!=='lobby')return sendJson(res,409,{ok:false,message:'Đội đã bắt đầu. Chỉ thành viên cũ mới có thể đăng nhập lại bằng đúng tên trước đó.'});
        idx=Array.from({length:4},(_,i)=>i).find(i=>!team.players[i]);if(idx==null)return sendJson(res,409,{ok:false,message:'Phòng đã đủ 4 thành viên.'});
        team.players[idx]=playerName;team.playerJoinedAt[idx]=now();engine.setActivePlayers(room.game,team.players);saveDb();audit('team.player_join',{teamId:team.id,playerId:idx+1,name:playerName});
      }else{engine.setActivePlayers(room.game,team.players)}
      clearLoginLimit(req,loginCode);const key=`${team.id}:${idx+1}`,old=activePlayerSession.get(key);if(old)revokeSession(old);const ps=newSession({role:'player',teamId:team.id,playerId:idx+1,displayName:team.players[idx]});activePlayerSession.set(key,ps.token);
      audit('login.player',{teamId:team.id,playerId:idx+1,ip:clientIp(req)});return sendJson(res,200,{ok:true,session:ps.token,profile:{role:'player',teamId:team.id,teamName:team.name,playerId:idx+1,playerName:team.players[idx],players:team.players},event:publicEvent()});
    }
    if(url.pathname==='/api/auth/observer'&&req.method==='POST'){
      const b=await readBody(req);if(!checkLoginLimit(req,b.account))return sendJson(res,429,{ok:false,message:'Thử lại sau vài phút.'});const team=findTeamByAccount(b.account);if(!team||normalize(b.code)!==normalize(team.observerCode))return sendJson(res,401,{ok:false,message:'Mã đội chơi hoặc mã quan sát không đúng.'});clearLoginLimit(req,b.account);const s=newSession({role:'observer',teamId:team.id,viewPlayer:1},OBSERVER_TTL);audit('login.observer',{teamId:team.id,ip:clientIp(req)});return sendJson(res,200,{ok:true,session:s.token,profile:{role:'observer',teamId:team.id,teamName:team.name,playerId:1,playerName:'Người quan sát',players:team.players},event:publicEvent()});
    }
    if(url.pathname==='/api/auth/admin'&&req.method==='POST'){
      if(!ADMIN_REMOTE&&!isLocal(req))return sendJson(res,403,{ok:false,message:'Chỉ đăng nhập quản trị trên máy chủ.'});const b=await readBody(req);if(!checkLoginLimit(req,b.username))return sendJson(res,429,{ok:false,message:'Thử lại sau vài phút.'});const ok=crypto.timingSafeEqual(Buffer.from(crypto.createHash('sha256').update(String(b.password||'')).digest()),Buffer.from(crypto.createHash('sha256').update(ADMIN_PASSWORD).digest()))&&String(b.username||'')===ADMIN_USER;if(!ok)return sendJson(res,401,{ok:false,message:'Sai tài khoản hoặc mật khẩu quản trị.'});clearLoginLimit(req,b.username);const s=newSession({role:'admin'});audit('login.admin',{ip:clientIp(req)});return sendJson(res,200,{ok:true,session:s.token,profile:{role:'admin',username:ADMIN_USER}});
    }
    if(url.pathname==='/api/auth/logout'&&req.method==='POST'){const token=sessionToken(req,url),s0=sessions.get(token);if(s0?.role==='player'){const team=db.teams.find(t=>t.id===s0.teamId),room=team&&roomForTeam(team.id);if(team&&room&&room.game.phase==='lobby'&&!team.rosterLocked){removePlayerSlot(team,s0.playerId-1,'logout');saveDb();}}revokeSession(token);return sendJson(res,200,{ok:true})}
    if(url.pathname==='/api/session'&&req.method==='GET'){
      const s=getSession(req,url,['player','observer','admin-observer','admin']);if(!s)return sendJson(res,401,{ok:false});if(s.role==='admin')return sendJson(res,200,{ok:true,profile:{role:'admin',username:ADMIN_USER},event:publicEvent()});const team=db.teams.find(t=>t.id===s.teamId&&!t.disabled);if(!team)return sendJson(res,404,{ok:false});return sendJson(res,200,{ok:true,profile:{role:s.role,teamId:team.id,teamName:team.name,playerId:s.playerId||s.viewPlayer||1,playerName:s.displayName||'Người quan sát',players:team.players},event:publicEvent()});
    }

    if(url.pathname==='/api/state'&&req.method==='GET'){
      const s=getSession(req,url,['player','observer','admin-observer']);if(!s)return sendJson(res,401,{ok:false,message:'Hãy đăng nhập lại.'});const state=stateForSession(s,true,url.searchParams.get('view'));if(!state)return sendJson(res,404,{ok:false});return sendJson(res,200,state);
    }
    if(url.pathname==='/api/ready'&&req.method==='POST'){
      const session=getSession(req,url,['player']);if(!session)return sendJson(res,401,{ok:false});
      const team=db.teams.find(t=>t.id===session.teamId&&!t.disabled),room=team&&roomForTeam(session.teamId);
      if(!team||!room)return sendJson(res,404,{ok:false,message:'Không tìm thấy phòng đội.'});
      if(db.event.status!=='running')return sendJson(res,409,{ok:false,message:'Ban tổ chức chưa mở bắt đầu.'});
      if(room.game.phase!=='lobby')return sendJson(res,409,{ok:false,message:'Đội đã bắt đầu.'});
      const b=await readBody(req);claimPlayer(room,session);engine.setReady(room.game,session.playerId,b.ready!==false);
      const result=tryCoordinatedStart(team,room);saveDb();
      return sendJson(res,200,{ok:true,...result});
    }
    if(url.pathname==='/api/input'&&req.method==='POST'){
      const s=getSession(req,url,['player']);if(!s)return sendJson(res,401,{ok:false});if(db.event.status!=='running')return sendJson(res,409,{ok:false,message:db.event.status==='paused'?'Sự kiện đang tạm dừng.':'Sự kiện chưa bắt đầu.'});const room=roomForTeam(s.teamId);const b=await readBody(req);claimPlayer(room,s);engine.applyInput(room.game,s.playerId,b);return sendJson(res,200,{ok:true});
    }
    if(url.pathname==='/api/code'&&req.method==='POST'){
      const s=getSession(req,url,['player']);if(!s)return sendJson(res,401,{ok:false});if(db.event.status!=='running')return sendJson(res,409,{ok:false,message:'Sự kiện chưa chạy.'});const b=await readBody(req);const room=roomForTeam(s.teamId);const r=engine.submitCode(room.game,b.code);return sendJson(res,200,r);
    }
    if(url.pathname==='/api/restart'&&req.method==='POST'){
      const s=getSession(req,url,['player']);if(!s)return sendJson(res,401,{ok:false});const room=roomForTeam(s.teamId);if(room.game.phase!=='done')return sendJson(res,409,{ok:false,message:'Chỉ quay lại sau khi hoàn thành.'});revokeSession(s.token);return sendJson(res,200,{ok:true});
    }
    if(url.pathname==='/api/disconnect'&&req.method==='POST'){
      const s=getSession(req,url,['player']);if(!s)return sendJson(res,200,{ok:true});const room=roomForTeam(s.teamId);engine.disconnectPlayer(room.game,s.playerId,s.token);return sendJson(res,200,{ok:true});
    }

    if(url.pathname==='/api/admin/dashboard'&&req.method==='GET'){
      if(!requireAdmin(req,res,url))return;return sendJson(res,200,{ok:true,event:publicEvent(),teams:db.teams.map(teamSummary).sort((a,b)=>{if(a.completionMs!=null&&b.completionMs!=null)return a.completionMs-b.completionMs;if(a.completionMs!=null)return-1;if(b.completionMs!=null)return 1;return a.name.localeCompare(b.name,'vi')}),server:{uptime:process.uptime(),wsClients:wsClients.size,sessions:sessions.size,memoryMb:Math.round(process.memoryUsage().rss/1048576),eventLoopLagMs:Math.round(eventLoopLagMs)}});
    }
    if(url.pathname==='/api/admin/event'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),action=String(b.action||'');
      if(action==='start'){db.event.status='running';db.event.startedAt=db.event.startedAt||now();db.event.endedAt=null;for(const team of db.teams){if(team.disabled)continue;const room=roomForTeam(team.id);if(room&&room.game.phase==='lobby'){team.rosterLocked=false;engine.setActivePlayers(room.game,team.players);room.game.players.forEach(p=>p.ready=false);team.completionMs=null;team.finishedAt=null}}}
      else if(action==='start_force'){db.event.status='running';db.event.startedAt=db.event.startedAt||now();db.event.endedAt=null;for(const team of db.teams){if(team.disabled)continue;const room=roomForTeam(team.id);if(room&&room.game.phase==='lobby'&&roomOnlineCount(room)>=3)prepareImmediateStart(team,room)}}
      else if(action==='pause'&&db.event.status==='running'){db.event.status='paused';db.event.pausedAt=now()}
      else if(action==='resume'&&db.event.status==='paused'){db.event.status='running';if(db.event.pausedAt)db.event.totalPausedMs=(db.event.totalPausedMs||0)+(now()-db.event.pausedAt);db.event.pausedAt=null}
      else if(action==='end'){db.event.status='ended';db.event.endedAt=now()}
      else if(action==='registration'){db.event.status='registration';db.event.startedAt=null;db.event.endedAt=null;db.event.pausedAt=null;db.event.totalPausedMs=0;for(const team of db.teams){team.rosterLocked=false;const room=roomForTeam(team.id);room?.game?.players?.forEach(p=>p.ready=false)}}
      else if(action==='reset_all'){for(const team of db.teams){const room=roomForTeam(team.id);if(room){engine.setActivePlayers(room.game,team.players);engine.resetGame(room.game)}team.rosterLocked=false;team.completionMs=null;team.finishedAt=null}db.event.status='registration';db.event.startedAt=null;db.event.endedAt=null}
      else return sendJson(res,400,{ok:false,message:'Thao tác không hợp lệ.'});saveDb();audit('event.'+action);return sendJson(res,200,{ok:true,event:publicEvent()});
    }
    if(url.pathname==='/api/admin/team/import'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req,262144);const result=importTeamsCsv(b.csv);audit('team.import',{imported:result.imported,errorCount:result.errors.length});return sendJson(res,result.imported?200:400,{ok:result.imported>0,...result});
    }
    if(url.pathname==='/api/admin/team/create'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),account=safeAccount(b.account),name=cleanText(b.name,60),password=String(b.password||'');if(!account||!name||password.length<6)return sendJson(res,400,{ok:false,message:'Cần tên đội, mã đội chơi và mật khẩu ít nhất 6 ký tự.'});if(codeInUse(account))return sendJson(res,409,{ok:false,message:'Mã đội chơi đã tồn tại hoặc trùng mã quan sát.'});let id=safeAccount(b.id||account)||randomToken(6).toLowerCase();while(db.teams.some(t=>t.id===id))id=`${id}-${Math.floor(Math.random()*99)+1}`;const observerCode=cleanText(b.observerCode||randomToken(6),32);if(codeInUse(observerCode))return sendJson(res,409,{ok:false,message:'Mã quan sát đã tồn tại hoặc trùng mã đội chơi.'});const team={id,name,account,passwordHash:passwordHash(password),observerCode,players:[],playerJoinedAt:[],rosterLocked:false,createdAt:now(),disabled:false,completionMs:null,finishedAt:null};db.teams.push(team);createRoom(team);saveDb();audit('team.create',{teamId:id});return sendJson(res,201,{ok:true,team:teamSummary(team)});
    }
    if(url.pathname==='/api/admin/team/update'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),team=db.teams.find(t=>t.id===String(b.id));if(!team)return sendJson(res,404,{ok:false,message:'Không tìm thấy đội.'});if(b.name!=null)team.name=cleanText(b.name,60)||team.name;if(b.account!=null){const a=safeAccount(b.account);if(!a)return sendJson(res,400,{ok:false,message:'Mã đội chơi không hợp lệ.'});if(codeInUse(a,team.id))return sendJson(res,409,{ok:false,message:'Mã đội chơi đã tồn tại hoặc trùng mã quan sát.'});team.account=a}if(String(b.password||'').length)team.passwordHash=passwordHash(String(b.password));if(b.observerCode!=null){const oc=cleanText(b.observerCode,32);if(!oc)return sendJson(res,400,{ok:false,message:'Mã quan sát không hợp lệ.'});if(codeInUse(oc,team.id))return sendJson(res,409,{ok:false,message:'Mã quan sát đã tồn tại hoặc trùng mã đội chơi.'});team.observerCode=oc;}if(b.disabled!=null){team.disabled=!!b.disabled;if(team.disabled)for(const [tok,s] of [...sessions])if(s.teamId===team.id)revokeSession(tok)}saveDb();audit('team.update',{teamId:team.id});return sendJson(res,200,{ok:true,team:teamSummary(team)});
    }
    if(url.pathname==='/api/admin/team/delete'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),id=String(b.id||''),idx=db.teams.findIndex(t=>t.id===id);if(idx<0)return sendJson(res,404,{ok:false});db.teams.splice(idx,1);rooms.delete(id);for(const [token,s] of sessions)if(s.teamId===id)revokeSession(token);saveDb();audit('team.delete',{teamId:id});return sendJson(res,200,{ok:true});
    }
    if(url.pathname==='/api/admin/team/control'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),team=db.teams.find(t=>t.id===String(b.id)),room=team&&roomForTeam(team.id);if(!team||!room)return sendJson(res,404,{ok:false});const action=String(b.action||'');
      if(action==='reset'){engine.setActivePlayers(room.game,team.players);engine.resetGame(room.game);team.rosterLocked=false;team.completionMs=null;team.finishedAt=null;room.connectionPaused=false;room.resumeAt=0}
      else if(action==='start'){if(db.event.status!=='running')return sendJson(res,409,{ok:false,message:'Hãy mở sự kiện trước.'});if(room.game.phase!=='lobby')return sendJson(res,409,{ok:false,message:'Đội này đã bắt đầu hoặc đã hoàn thành.'});const started=prepareImmediateStart(team,room);if(!started.ok)return sendJson(res,409,started)}
      else if(action==='finish'){engine.forceFinish(room.game);persistTeamCompletion(team,room)}
      else if(action==='remove_player'){if(!['lobby','done'].includes(room.game.phase))return sendJson(res,409,{ok:false,message:'Chỉ xóa người chơi khi đội đang ở sảnh hoặc đã hoàn thành.'});const pid=clamp(Number(b.playerId)||0,1,4);if(!removePlayerSlot(team,pid-1,'admin'))return sendJson(res,404,{ok:false,message:'Vị trí này không có người chơi.'});}
      else return sendJson(res,400,{ok:false});saveDb();audit(`team.${action}`,{teamId:team.id,playerId:b.playerId||null});return sendJson(res,200,{ok:true});
    }
    if(url.pathname==='/api/admin/observer-session'&&req.method==='POST'){
      if(!requireAdmin(req,res,url))return;const b=await readBody(req),team=db.teams.find(t=>t.id===String(b.id));if(!team)return sendJson(res,404,{ok:false});const s=newSession({role:'admin-observer',teamId:team.id,viewPlayer:1},OBSERVER_TTL);return sendJson(res,200,{ok:true,session:s.token,profile:{role:'observer',teamId:team.id,teamName:team.name,playerId:1,playerName:'Người quan sát',players:team.players}});
    }
    if(url.pathname==='/api/admin/audit'&&req.method==='GET'){
      if(!requireAdmin(req,res,url))return;let body;try{body=fs.readFileSync(AUDIT_FILE)}catch{body=Buffer.from('')};res.writeHead(200,{...securityHeaders(),'Content-Type':'application/x-ndjson; charset=utf-8','Content-Disposition':'attachment; filename="gameday-audit.ndjson"','Content-Length':body.length});return res.end(body);
    }
    if(url.pathname==='/api/admin/export'&&req.method==='GET'){
      if(!requireAdmin(req,res,url))return;const rows=db.teams.map(teamSummary);const csv=['STT,Tên đội,Mã đội chơi,Trạng thái,Tầng,Trực tuyến,Thời gian,Thời gian hoàn thành',...rows.map((t,i)=>[i+1,t.name,t.account,t.status,t.stage,t.online,t.elapsedText,t.completionText].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(','))].join('\r\n');const body=Buffer.concat([Buffer.from('\ufeff'),Buffer.from(csv)]);res.writeHead(200,{...securityHeaders(),'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="gameday-ket-qua.csv"','Content-Length':body.length});return res.end(body);
    }
    if(url.pathname.startsWith('/api/'))return sendJson(res,404,{ok:false,message:'API không tồn tại.'});
    serveStatic(req,res,url.pathname);
  }catch(e){console.error(e);if(!res.headersSent)sendJson(res,e.statusCode||500,{ok:false,message:e.statusCode?'Yêu cầu không hợp lệ.':'Lỗi máy chủ.'});else res.end()}
});
server.on('upgrade',handleWsUpgrade);
server.keepAliveTimeout=65000;server.headersTimeout=66000;server.requestTimeout=15000;server.maxHeadersCount=64;
server.listen(PORT,'0.0.0.0',()=>{
  console.log(`\nRUNNING CVA - CHURAMID V13.10: http://localhost:${PORT}`);
  console.log(`Trang quản trị: http://localhost:${PORT}/admin`);
  console.log(`Tài khoản quản trị mặc định: ${ADMIN_USER} / ${ADMIN_PASSWORD}`);
  console.log(`Đội thử nghiệm: demo / demo123 / tên người chơi tự nhập`);
  if(ADMIN_PASSWORD==='cva2026')console.warn('CẢNH BÁO: Hãy đổi ADMIN_PASSWORD trước ngày sự kiện.');
});
