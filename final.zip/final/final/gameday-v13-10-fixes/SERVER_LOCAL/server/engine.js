
'use strict';

let ALLOW_CHEAT=true;
const PLAYER_TIMEOUT=12000;
let game=null;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const now = () => Date.now();
function seeded(seed) {
  let s = seed >>> 0;
  return () => {
    s += 0x6D2B79F5;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PLAYER_INFO = [
  { id: 1, name: 'Ranger', color: '#55d68b', sprite: 'p1' },
  { id: 2, name: 'Orc', color: '#54a8ff', sprite: 'p2' },
  { id: 3, name: 'Dark Oracle', color: '#b878ff', sprite: 'p3' },
  { id: 4, name: 'Fallen Angel', color: '#ff9f55', sprite: 'p4' },
];


function createGame(displayNames=[], teamId='') {
  const names=Array.from({length:4},(_,i)=>String(displayNames[i]||'').trim().slice(0,40));
  return {
    teamId, stage:0, phase:'lobby', countdown:0, elapsed:0, totalElapsed:0, timerStarted:false, transitionTo:0, transitionTimer:0,
    cheat:false, revision:0, message:'', stageAcks:[false,false,false,false], createdAt:Date.now(), finishedAt:null,
    players:PLAYER_INFO.map((p,i)=>({...p,displayName:names[i]||`Vị trí ${i+1}`,active:!!names[i],x:0,y:0,vx:0,vy:0,facing:1,anim:0,input:{up:false,down:false,left:false,right:false},actions:[],connected:false,ready:false,lastSeen:0,escaped:false,needsNeutral:true,clientToken:'',lastInputSeq:0,lastActionSeq:0,lastInputAt:0})),
    map1:null,map2:null,map3:null,events:PLAYER_INFO.map(()=>[])
  };
}
function useGame(g){game=g;return g}
function setAllowCheat(v){ALLOW_CHEAT=!!v}
function playerLabel(i){const p=game?.players?.[i];return p?.displayName||`Người chơi ${i+1}`;}
function activePlayers(){return game.players.filter(p=>p.active)}
function activePlayerCount(){return activePlayers().length}
function activeExplorers(){return game.players.filter(p=>p.active&&p.id!==1)}
function resetLobby() {
  game.stage=0;game.phase='lobby';game.cheat=false;game.elapsed=0;game.totalElapsed=0;game.timerStarted=false;game.transitionTo=0;game.transitionTimer=0;game.stageAcks=[false,false,false,false];
  game.players.forEach(p=>{p.ready=false;p.escaped=false;p.vx=0;p.vy=0;p.input={up:false,down:false,left:false,right:false};p.actions.length=0;p.needsNeutral=true;});
}
function emitTo(playerId, type, data = {}) {
  const i = clamp(Number(playerId) - 1, 0, 3);
  game.events[i].push({ id: `${Date.now()}-${Math.random()}`, type, ...data });
  if (game.events[i].length > 20) game.events[i].shift();
}
function emitAll(type, data = {}) {
  for (let i = 1; i <= 4; i++) emitTo(i, type, data);
}
function connectedCount() {
  const n = now();
  return activePlayers().filter(p => p.connected && n - p.lastSeen < PLAYER_TIMEOUT).length;
}
function allReady() {
  const n = now();
  const active=activePlayers();return active.length>=3&&active.every(p => p.connected && n - p.lastSeen < PLAYER_TIMEOUT && p.ready);
}
function allActiveEscaped() {
  const active=activePlayers();return active.length>=3&&active.every(p => p.escaped);
}
function resetPlayerMotion() {
  for (const p of game.players) {
    p.vx = 0; p.vy = 0; p.anim = 0; p.escaped = false; p.needsNeutral = true;
    p.input = { up:false, down:false, left:false, right:false };
    p.actions.length = 0;
  }
}

const MAP1 = {
  worldW: 1800, worldH: 1200, wall: 72, centerX: 900, centerY: 640,
  ringX: 560, ringY: 330,
  puzzles: [[2, 5, 9, 12], [1, 4, 7, 10], [3, 6, 8, 11], [2, 4, 9, 11]],
  features: ['red_nose', 'square', 'yellow_eyes', 'swapped_collar'],
};
function map1Cats(hours) {
  const cats = [];
  for (let hour = 1; hour <= 12; hour++) {
    const a = (hour % 12) * Math.PI / 6 - Math.PI / 2;
    cats.push({ hour, x: MAP1.centerX + Math.cos(a) * MAP1.ringX, y: MAP1.centerY + Math.sin(a) * MAP1.ringY, feature: null });
  }
  hours.forEach((h, i) => { cats[h - 1].feature = MAP1.features[i]; });
  return cats;
}
function setupMap1(puzzleIndex = 0) {
  resetPlayerMotion();
  const starts = [
    { x: 780, y: 1080 }, { x: 860, y: 1080 }, { x: 940, y: 1080 }, { x: 1020, y: 1080 },
  ];
  game.players.forEach((p, i) => Object.assign(p, starts[i]));
  const hours = MAP1.puzzles[puzzleIndex % MAP1.puzzles.length];
  game.map1 = {
    puzzleIndex: puzzleIndex % MAP1.puzzles.length,
    specialHours: hours,
    cats: map1Cats(hours),
    solved: false,
  };
}

const MAP2 = { worldW: 5520, worldH: 900, top: 120, bottom: 790, doorX: 5260, doorY: 410 };
function setupMap2() {
  resetPlayerMotion();
  const starts = [
    { x: 150, y: 360 }, { x: 150, y: 440 }, { x: 230, y: 360 }, { x: 230, y: 440 },
  ];
  game.players.forEach((p, i) => Object.assign(p, starts[i]));
  const rnd = seeded(22026);
  const golems = Array.from({ length: 15 }, (_, i) => ({
    x: 720 + i * 290 + (rnd() - .5) * 70,
    y: MAP2.top + 70 + rnd() * (MAP2.bottom - MAP2.top - 140),
    baseY: MAP2.top + 70 + rnd() * (MAP2.bottom - MAP2.top - 140),
    model: i % 3, facing: -1, anim: rnd() * 5, state: 'idle',
  }));
  golems.forEach(g=>{g.homeX=g.x;g.homeY=g.y;g.baseY=g.y;});
  const muds = Array.from({ length: 14 }, () => ({
    x: 850 + rnd() * 4100,
    y: MAP2.top + 60 + rnd() * (MAP2.bottom - MAP2.top - 120),
    r: 50 + rnd() * 22,
  }));
  const firstActive=Math.max(0,game.players.findIndex(p=>p.active));
  game.map2 = {
    holder: firstActive, ballPass: null, delivered: false, doorProgress: 0,
    golems, muds, caughtTimer: 0, resetCount: 0,
  };
}

const M3 = { cols: 39, rows: 25, seed: 20260716, keyDoor: { x: 16, y: 12 }, key: { x: 19, y: 12 }, chest: { x: 37, y: 23 } };
function cellKey(x, y) { return `${x},${y}`; }
function generateMaze() {
  const cols = M3.cols, rows = M3.rows, rnd = seeded(M3.seed);
  const maze = Array.from({ length: rows }, () => Array(cols).fill(1));
  const frontier = [], seen = new Set();
  function inside(x, y) { return x > 0 && y > 0 && x < cols - 1 && y < rows - 1; }
  function add(x, y) {
    for (const [dx, dy] of [[2,0],[-2,0],[0,2],[0,-2]]) {
      const tx = x + dx, ty = y + dy, wx = x + dx / 2, wy = y + dy / 2;
      if (!inside(tx, ty) || maze[ty][tx] === 0) continue;
      const k = `${wx},${wy}>${tx},${ty}`;
      if (!seen.has(k)) { seen.add(k); frontier.push({ wx, wy, tx, ty }); }
    }
  }
  maze[1][1] = 0; add(1, 1);
  while (frontier.length) {
    const i = Math.floor(rnd() * frontier.length), f = frontier.splice(i, 1)[0];
    if (maze[f.ty][f.tx] === 0) continue;
    maze[f.wy][f.wx] = 0; maze[f.ty][f.tx] = 0; add(f.tx, f.ty);
  }
  const candidates = [];
  for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) if (maze[y][x] === 1) {
    const h = maze[y][x-1] === 0 && maze[y][x+1] === 0;
    const v = maze[y-1][x] === 0 && maze[y+1][x] === 0;
    if (h !== v) candidates.push({ x, y });
  }
  for (let i = candidates.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [candidates[i], candidates[j]] = [candidates[j], candidates[i]]; }
  candidates.slice(0, 72).forEach(c => { maze[c.y][c.x] = 0; });

  // Phòng chìa khóa kín ở giữa, chỉ có cửa phía tây.
  for (let y = 9; y <= 15; y++) for (let x = 16; x <= 22; x++) maze[y][x] = 1;
  for (let y = 10; y <= 14; y++) for (let x = 17; x <= 21; x++) maze[y][x] = 0;
  maze[12][16] = 0; maze[12][15] = 0;
  // Tạo đường vòng tự nhiên quanh phòng.
  const lines = [
    [[15,12],[14,12],[14,8],[18,8],[18,7],[24,7]],
    [[24,7],[24,11],[25,11],[25,16],[21,16],[21,17],[14,17],[14,12]],
  ];
  function carve(a, b) {
    if (a[0] === b[0]) for (let y = Math.min(a[1],b[1]); y <= Math.max(a[1],b[1]); y++) maze[y][a[0]] = 0;
    else for (let x = Math.min(a[0],b[0]); x <= Math.max(a[0],b[0]); x++) maze[a[1]][x] = 0;
  }
  lines.forEach(line => { for (let i = 1; i < line.length; i++) carve(line[i-1], line[i]); });
  // Lối và rương ở góc phải dưới.
  maze[23][35] = 0; maze[23][36] = 0; maze[23][37] = 0;
  // Ba điểm xuất phát.
  maze[1][1] = 0; maze[23][1] = 0; maze[1][37] = 0;
  return maze;
}
function floorCells(maze) {
  const out = [];
  for (let y = 1; y < M3.rows - 1; y++) for (let x = 1; x < M3.cols - 1; x++) if (maze[y][x] === 0) out.push({ x, y });
  return out;
}
function nearestFloor(maze, anchor, banned = []) {
  const cells = floorCells(maze);
  const ok = c => !banned.some(b => Math.hypot(c.x - b.x, c.y - b.y) < 4);
  return cells.filter(ok).sort((a,b) => (Math.abs(a.x-anchor.x)+Math.abs(a.y-anchor.y))-(Math.abs(b.x-anchor.x)+Math.abs(b.y-anchor.y)))[0];
}
function setupMap3() {
  resetPlayerMotion();
  const maze = generateMaze();
  const starts = [
    { x: 3.5, y: 3.5 },
    { x: 1.5, y: 1.5 },
    { x: 1.5, y: 23.5 },
    { x: 37.5, y: 1.5 },
  ];
  game.players.forEach((p, i) => Object.assign(p, starts[i]));
  const leverA = nearestFloor(maze, { x: 10, y: 7 }, [M3.keyDoor, M3.key, M3.chest]);
  const leverB = nearestFloor(maze, { x: 11, y: 18 }, [leverA, M3.keyDoor, M3.key, M3.chest]);
  const rnd = seeded(33026);
  const specials = [leverA, leverB, M3.keyDoor, M3.key, M3.chest, ...starts];
  const candidates = floorCells(maze).filter(c => specials.every(s => Math.hypot(c.x - s.x, c.y - s.y) > 2.4));
  const muds = [];
  for (let i = 0; i < 16; i++) {
    const idx = Math.floor((i + .5) * candidates.length / 16);
    const c = candidates[clamp(idx + Math.floor((rnd()-.5)*10), 0, candidates.length-1)];
    if (c && !muds.some(v=>Math.hypot(v.x-c.x,v.y-c.y)<2.2)) muds.push({ x: c.x + .5, y: c.y + .5, r: .48 + rnd()*.08 });
  }
  // Golem tuần tra rộng quanh nửa phải mê cung nhưng vẫn ưu tiên khu vực kho báu.
  const patrolAnchors = [{x:34,y:22},{x:29,y:20},{x:34,y:16},{x:27,y:13},{x:35,y:10},{x:30,y:7}];
  const patrolPoints = [];
  for (const anchor of patrolAnchors) {
    const p = nearestFloor(maze, anchor, [...starts, leverA, leverB, M3.key, ...patrolPoints]);
    if (p && !patrolPoints.some(v=>Math.hypot(v.x-p.x,v.y-p.y)<3)) patrolPoints.push({x:p.x+.5,y:p.y+.5});
  }
  if (!patrolPoints.length) patrolPoints.push({x:35.5,y:23.5});
  const golemStart = patrolPoints[0];
  game.map3 = {
    maze, leverCells: [leverA, leverB], leverOn: [false, false],
    keyDoorOpen: false, keyDoorProgress: 0, keyTaken: false,
    chestOpen: false, chestProgress: 0,
    muds,
    patrolPoints,
    golems: [{ x: golemStart.x, y: golemStart.y, homeX: golemStart.x, homeY: golemStart.y, model: 1, facing: 1, anim: 0, path: [], pathIndex: 0, repath: 0, targetId: 0, targetCell:'', mode:'patrol', patrolIndex:1, patrolWait:0, alertTimer:0 }],
    cursor: { x: 1, y: 1 }, markers: [], cursorCooldown: 0,
  };
}

function startStage(stage) {
  game.stage = stage;
  game.phase = 'briefing';
  game.countdown = 12.0;
  game.stageAcks = [false, false, false, false];
  game.players.forEach(p=>{p.ready=false;});
  game.transitionTo = 0; game.transitionTimer = 0;
  game.elapsed = 0;
  game.message = '';
  if (stage === 1) setupMap1(0);
  else if (stage === 2) setupMap2();
  else if (stage === 3) setupMap3();
  game.revision++;
  emitAll('stage', { stage });
}
function beginTransition(to) {
  if (game.phase === 'done') return;
  game.players.forEach(p=>{p.vx=0;p.vy=0;p.input={up:false,down:false,left:false,right:false};p.actions.length=0;p.needsNeutral=true;});
  // Không hiện màn "đang chuyển": mở ngay hướng dẫn của tầng kế tiếp.
  startStage(to);
}
function resetCurrent(reason) {
  if (game.cheat || game.phase !== 'playing') return;
  game.players.forEach(p=>{p.vx=0;p.vy=0;p.input={up:false,down:false,left:false,right:false};p.actions.length=0;p.needsNeutral=true;});
  game.phase = 'resetting';
  game.countdown = 2.6;
  game.message = reason;
  emitAll('reset', { reason });
}

function briefingReadyCount() { return 0; }
function queueOrHandleAction(player, action) {
  player.actions.push(action);
  return true;
}

function movementVector(input) {
  let x = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  let y = (input.down ? 1 : 0) - (input.up ? 1 : 0);
  const m = Math.hypot(x, y) || 1;
  return { x: x / m, y: y / m, moving: !!(x || y) };
}
function movePlayer(p, dt, speed, blocked) {
  if (p.escaped) return;
  const d = movementVector(p.input);
  const mult = game.cheat ? 2.15 : 1;
  p.vx = d.x * speed * mult;
  p.vy = d.y * speed * mult;
  if (Math.abs(p.vx) > .001) p.facing = Math.sign(p.vx);
  if (!d.moving) { p.vx = 0; p.vy = 0; return; }

  // Di chuyển trực tiếp, chia bước nhỏ để client/server va chạm giống nhau.
  // Bỏ quán tính cũ vì nó làm nhân vật bị đẩy thêm một nhịp khi thả phím.
  const totalX = p.vx * dt, totalY = p.vy * dt;
  const maxStep = speed < 20 ? .075 : 7;
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(totalX), Math.abs(totalY)) / maxStep));
  const stepX = totalX / steps, stepY = totalY / steps;
  for (let i = 0; i < steps; i++) {
    const nx = p.x + stepX;
    if (game.cheat || !blocked(nx, p.y)) p.x = nx; else p.vx = 0;
    const ny = p.y + stepY;
    if (game.cheat || !blocked(p.x, ny)) p.y = ny; else p.vy = 0;
  }
  p.anim += dt;
}

function ellipseHit(px, py, cx, cy, rx, ry) {
  const dx=(px-cx)/rx,dy=(py-cy)/ry;
  return dx*dx+dy*dy<1;
}
function map1Blocked(x, y) {
  // Tọa độ người chơi nằm tại chân sprite. Chỉ khóa phần đế thật của tượng,
  // không dùng vòng tròn bao toàn ảnh nên không còn vùng trống vô hình.
  const prX=23,prY=16;
  if (x < MAP1.wall + prX || x > MAP1.worldW - MAP1.wall - prX || y < MAP1.wall + prY || y > MAP1.worldH - MAP1.wall - prY) return true;
  // Nhân sư được vẽ chạm sàn tại y=690, không phải tâm vòng tròn y=640.
  if (ellipseHit(x,y,MAP1.centerX,690,76+prX,31+prY)) return true;
  for (const c of game.map1.cats) if (ellipseHit(x,y,c.x,c.y-5,34+prX,18+prY)) return true;
  return false;
}
function updateMap1(dt) {
  for (const p of activePlayers()) {
    movePlayer(p, dt, 245, map1Blocked);
    p.x=clamp(p.x,10,MAP1.worldW-10);p.y=clamp(p.y,10,MAP1.worldH-10);
  }
}

function ballPosition() {
  const m = game.map2;
  if (m.ballPass) {
    const from = game.players[m.ballPass.from], to = game.players[m.ballPass.to];
    const t = clamp(m.ballPass.t / m.ballPass.duration, 0, 1);
    return { x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t - Math.sin(Math.PI * t) * 80 };
  }
  const p = game.players[m.holder];
  return { x: p.x, y: p.y - 72 };
}
function map2Blocked(x, y) {
  if (x < 40 || x > MAP2.doorX + 12 || y < MAP2.top || y > MAP2.bottom) return true;
  if (x > MAP2.doorX - 72) {
    const insideOpening = Math.abs(y - MAP2.doorY) < 86;
    if (!insideOpening) return true;
    if (!game.map2.delivered && x > MAP2.doorX - 42) return true;
  }
  return false;
}
function handleMap2Pass(playerIndex) {
  const m = game.map2;

  if (
    !game.players[playerIndex]?.active ||
    m.ballPass ||
    m.delivered ||
    m.holder !== playerIndex
  ) return;

  const from = game.players[playerIndex];
  const PASS_RANGE = 420;
  const FORWARD_GAP = 30;
  const MAX_VERTICAL_GAP = 220;

  let nearestAhead = null;
  let nearestAheadDistance = Infinity;

  let nearestAny = null;
  let nearestAnyDistance = Infinity;

  game.players.forEach((p, i) => {
    if (
      !p.active ||
      i === playerIndex ||
      p.escaped
    ) return;

    const d = dist(from, p);

    if (d > PASS_RANGE) return;

    // Phương án dự phòng: người gần nhất bất kỳ
    if (d < nearestAnyDistance) {
      nearestAnyDistance = d;
      nearestAny = i;
    }

    // Ưu tiên người đang ở phía trước theo hướng cuối map
    // Không xét nhân vật đang quay mặt về đâu
    const isAhead =
      p.x > from.x + FORWARD_GAP &&
      Math.abs(p.y - from.y) <= MAX_VERTICAL_GAP;

    if (isAhead && d < nearestAheadDistance) {
      nearestAheadDistance = d;
      nearestAhead = i;
    }
  });

  const target =
    nearestAhead !== null
      ? nearestAhead
      : nearestAny;

  if (target === null) {
    emitTo(playerIndex + 1, 'toast', {
      text: 'Không có đồng đội trong tầm chuyền.',
      kind: 'bad'
    });

    return;
  }

  m.ballPass = {
    from: playerIndex,
    to: target,
    t: 0,
    duration: 0.42
  };

  emitAll('toast', {
    text:
      `${playerLabel(playerIndex)} chuyền cầu cho ` +
      `${playerLabel(target)}.`,
    kind: 'good'
  });
}
function resetMap2Positions() {
  const starts = [{ x:150,y:360},{x:150,y:440},{x:230,y:360},{x:230,y:440}];
  game.players.forEach((p,i)=>Object.assign(p,starts[i],{vx:0,vy:0,escaped:false,input:{up:false,down:false,left:false,right:false},needsNeutral:true}));
  game.map2.holder = Math.max(0,game.players.findIndex(p=>p.active)); game.map2.ballPass = null; game.map2.delivered = false; game.map2.doorProgress = 0;
  game.map2.golems.forEach(g=>{g.x=g.homeX;g.y=g.homeY;g.state='idle';});
}
function updateMap2(dt) {
  const m = game.map2;
  if (m.caughtTimer > 0) {
    m.caughtTimer -= dt;
    if (m.caughtTimer <= 0) { resetMap2Positions(); game.phase = 'countdown'; game.countdown = 2.8; }
    return;
  }
  if(!game.players[m.holder]?.active)m.holder=Math.max(0,game.players.findIndex(p=>p.active));
  for (const [i, p] of game.players.entries()) {
    if(!p.active)continue;
    const holding = m.holder === i && !m.ballPass && !m.delivered;
    let speed = 250 * (holding ? .76 : 1);
    if (m.muds.some(md => Math.hypot(p.x-md.x,p.y-md.y)<md.r)) speed *= .48;
    movePlayer(p, dt, speed, map2Blocked);
    p.x=clamp(p.x,40,m.delivered?MAP2.doorX+10:MAP2.doorX-42);p.y=clamp(p.y,MAP2.top,MAP2.bottom);
    if (m.delivered && p.x > MAP2.doorX - 24 && Math.abs(p.y - MAP2.doorY) < 86) { p.escaped = true; p.vx = 0; p.vy = 0; p.input={up:false,down:false,left:false,right:false}; p.needsNeutral=true; }
  }
  if (m.ballPass) {
    m.ballPass.t += dt;
    if (m.ballPass.t >= m.ballPass.duration) { m.holder = m.ballPass.to; m.ballPass = null; }
  }
  const b = ballPosition();
  for (const g of m.golems) {
    const dx=b.x-g.x,dy=b.y-g.y,d=Math.hypot(dx,dy)||1;
    const chase=d<520&&!m.delivered;
    if(chase){g.x+=dx/d*132*dt;g.y+=dy/d*132*dt;g.facing=dx<0?-1:1;g.state='chase';}
    else{g.y+=(g.baseY-g.y)*dt*.7;g.state='idle';}
    g.y=clamp(g.y,MAP2.top,MAP2.bottom);g.anim+=dt;
    const holder=game.players[m.holder];
    if(!game.cheat&&!m.ballPass&&!m.delivered&&Math.hypot(g.x-holder.x,g.y-holder.y)<62){
      m.resetCount++;m.caughtTimer=1.8;game.countdown=1.8;game.phase='resetting';game.message='Golem đã bắt được người cầm quả cầu.';emitAll('reset',{reason:game.message});return;
    }
  }
  if (!m.delivered && b.x > MAP2.doorX - 52 && b.y > MAP2.doorY - 178 && b.y < MAP2.doorY + 8) {
    m.delivered = true; m.doorProgress = .01; emitAll('toast', { text: 'Quả cầu đã đi vào cổng — cánh cửa tầng 3 đang mở!', kind: 'good' });
  }
  if (m.delivered) m.doorProgress = Math.min(1, m.doorProgress + dt * 1.35);
  if (allActiveEscaped()) beginTransition(3);
}

function m3Floor(x, y) { return y >= 0 && y < M3.rows && x >= 0 && x < M3.cols && game.map3.maze[y][x] === 0; }
function map3Blocked(x, y) {
  const r = .24;
  for (const [px, py] of [[x-r,y-r],[x+r,y-r],[x-r,y+r],[x+r,y+r]]) {
    const cx=Math.floor(px),cy=Math.floor(py);
    if(!m3Floor(cx,cy)) return true;
    if(!game.map3.keyDoorOpen&&cx===M3.keyDoor.x&&cy===M3.keyDoor.y) return true;
  }
  return false;
}
function nearCell(p, c, radius = .8) { return Math.hypot(p.x-(c.x+.5),p.y-(c.y+.5)) <= radius; }
function handleMap3Interact(index) {
  const m=game.map3,p=game.players[index];
  if(!p?.active)return;
  if(index===0){
    m.markers=m.markers.filter(v=>!(v.x===m.cursor.x&&v.y===m.cursor.y));
    return;
  }
  m.leverCells.forEach((c,i)=>{
    if(nearCell(p,c,1.25)){
      m.leverOn[i]=!m.leverOn[i];
      emitAll('toast',{text:`${playerLabel(index)} đã ${m.leverOn[i]?'gạt':'trả'} cần gạt ${i?'B':'A'}.`,kind:m.leverOn[i]?'good':'bad'});
    }
  });
  if(m.keyTaken&&!m.chestOpen&&nearCell(p,M3.chest,1.65)){
    m.chestOpen=true;m.chestProgress=.01;emitAll('toast',{text:`${playerLabel(index)} đã dùng chìa khóa mở rương kho báu!`,kind:'good'});
  }
}
function updateCommander(dt) {
  const p=game.players[0],m=game.map3;if(!p?.active)return;
  m.cursorCooldown=Math.max(0,m.cursorCooldown-dt);
  if(m.cursorCooldown<=0){
    let dx=(p.input.right?1:0)-(p.input.left?1:0),dy=(p.input.down?1:0)-(p.input.up?1:0);
    if(dx||dy){m.cursor.x=clamp(m.cursor.x+Math.sign(dx),0,M3.cols-1);m.cursor.y=clamp(m.cursor.y+Math.sign(dy),0,M3.rows-1);m.cursorCooldown=.12;}
  }
}
function processMap3CommanderAction(action) {
  const m=game.map3;
  if(action==='mark'||action==='danger'){
    m.markers=m.markers.filter(v=>!(v.x===m.cursor.x&&v.y===m.cursor.y));
    m.markers.push({x:m.cursor.x,y:m.cursor.y,type:action});
    if(m.markers.length>16)m.markers.shift();
  }
  if(action==='clear')m.markers=m.markers.filter(v=>!(v.x===m.cursor.x&&v.y===m.cursor.y));
}
function resetMap3Positions() {
  const starts=[{x:3.5,y:3.5},{x:1.5,y:1.5},{x:1.5,y:23.5},{x:37.5,y:1.5}];
  game.players.forEach((p,i)=>Object.assign(p,starts[i],{vx:0,vy:0,anim:0,escaped:false,input:{up:false,down:false,left:false,right:false},needsNeutral:true}));
  game.map3.leverOn=[false,false];game.map3.keyDoorOpen=false;game.map3.keyDoorProgress=0;game.map3.keyTaken=false;game.map3.chestOpen=false;game.map3.chestProgress=0;
  game.map3.golems.forEach(g=>{g.x=g.homeX;g.y=g.homeY;g.facing=1;g.path=[];g.pathIndex=0;g.repath=0;g.targetId=0;g.targetCell='';g.mode='patrol';g.patrolIndex=1;g.patrolWait=0;g.alertTimer=0;});
}
function map3CellPassable(x,y,doorOpen){
  if(y<0||y>=M3.rows||x<0||x>=M3.cols)return false;
  if(game.map3.maze[y][x]!==0)return false;
  if(!doorOpen&&x===M3.keyDoor.x&&y===M3.keyDoor.y)return false;
  return true;
}
function findMap3Path(fromX,fromY,toX,toY,doorOpen){
  const sx=clamp(Math.floor(fromX),0,M3.cols-1),sy=clamp(Math.floor(fromY),0,M3.rows-1);
  const tx=clamp(Math.floor(toX),0,M3.cols-1),ty=clamp(Math.floor(toY),0,M3.rows-1);
  if(sx===tx&&sy===ty)return[];
  const total=M3.cols*M3.rows,prev=new Int32Array(total);prev.fill(-1);
  const qx=new Int16Array(total),qy=new Int16Array(total);let head=0,tail=0;
  const start=sy*M3.cols+sx;prev[start]=start;qx[tail]=sx;qy[tail]=sy;tail++;
  const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
  while(head<tail){
    const x=qx[head],y=qy[head++];
    if(x===tx&&y===ty)break;
    for(const [dx,dy] of dirs){const nx=x+dx,ny=y+dy;if(!map3CellPassable(nx,ny,doorOpen))continue;const ni=ny*M3.cols+nx;if(prev[ni]!==-1)continue;prev[ni]=y*M3.cols+x;qx[tail]=nx;qy[tail]=ny;tail++;}
  }
  const target=ty*M3.cols+tx;if(prev[target]===-1)return[];
  const out=[];let cur=target;
  while(cur!==start){out.push({x:(cur%M3.cols)+.5,y:Math.floor(cur/M3.cols)+.5});cur=prev[cur];if(cur<0)return[];}
  out.reverse();return out;
}
function updateSmartGolem(g,dt){
  const m=game.map3;
  const explorers=activeExplorers().filter(p=>p.connected&&now()-p.lastSeen<PLAYER_TIMEOUT);
  const detectRadius=4.6,loseRadius=6.4;
  let nearest=null,nearestDist=Infinity;
  for(const p of explorers){const d=dist(g,p);if(d<nearestDist){nearestDist=d;nearest=p}}

  // Chỉ phát hiện khi người chơi tiến đủ gần. Sau khi mất dấu, Golem quay về tuần tra.
  if(nearest&&nearestDist<=detectRadius){g.mode='chase';g.targetId=nearest.id;g.alertTimer=1.15;}
  else if(g.mode==='chase'){
    const current=explorers.find(p=>p.id===g.targetId);
    if(current&&dist(g,current)<=loseRadius)g.alertTimer=1.15;
    else g.alertTimer=Math.max(0,(g.alertTimer||0)-dt);
    if(g.alertTimer<=0){g.mode='patrol';g.targetId=0;g.targetCell='';g.path=[];g.pathIndex=0;g.repath=0;}
  }

  let target=null;
  if(g.mode==='chase')target=explorers.find(p=>p.id===g.targetId)||nearest;
  if(!target){
    const points=m.patrolPoints||[{x:g.homeX,y:g.homeY}];
    g.patrolIndex=clamp(Number(g.patrolIndex)||0,0,points.length-1);
    target=points[g.patrolIndex];
    if(Math.hypot(target.x-g.x,target.y-g.y)<.28){
      g.patrolWait=Math.max(0,(g.patrolWait||.55)-dt);
      if(g.patrolWait>0){g.anim+=dt*.25;return false;}
      g.patrolIndex=(g.patrolIndex+1)%points.length;g.patrolWait=.55;target=points[g.patrolIndex];g.path=[];g.pathIndex=0;g.repath=0;
    }
  }
  if(!target)return false;

  g.repath=Math.max(0,(g.repath||0)-dt);
  const targetCell=`${Math.floor(target.x)},${Math.floor(target.y)}`;
  const targetId=g.mode==='chase'?(target.id||0):-(g.patrolIndex+1);
  if(g.repath<=0||g.targetPathId!==targetId||g.targetCell!==targetCell||!Array.isArray(g.path)||g.pathIndex>=g.path.length){
    g.path=findMap3Path(g.x,g.y,target.x,target.y,m.keyDoorOpen);g.pathIndex=0;g.repath=g.mode==='chase'?.34:.75;g.targetPathId=targetId;g.targetCell=targetCell;
  }
  let point=g.path?.[g.pathIndex];
  if(point&&Math.hypot(point.x-g.x,point.y-g.y)<.16){g.pathIndex++;point=g.path[g.pathIndex]}
  const goal=point||target,dx=goal.x-g.x,dy=goal.y-g.y,d=Math.hypot(dx,dy)||1;
  const speed=2.34; // 60% tốc độ người chơi (3.9)
  const totalX=dx/d*speed*dt,totalY=dy/d*speed*dt;
  const steps=Math.max(1,Math.ceil(Math.max(Math.abs(totalX),Math.abs(totalY))/.07));
  for(let i=0;i<steps;i++){
    const nx=g.x+totalX/steps;if(!map3Blocked(nx,g.y))g.x=nx;
    const ny=g.y+totalY/steps;if(!map3Blocked(g.x,ny))g.y=ny;
  }
  g.facing=dx<0?-1:1;g.anim+=dt;
  if(g.mode==='chase'&&!game.cheat)for(const p of explorers)if(dist(g,p)<.48){resetCurrent(`${p.displayName||playerLabel(p.id-1)} đã bị Golem bắt trong mê cung.`);return true;}
  return false;
}

function updateMap3(dt) {
  const m=game.map3;
  updateCommander(dt);
  for(const p of activeExplorers()){
    let speed=3.9;
    if(m.muds.some(md=>Math.hypot(p.x-md.x,p.y-md.y)<md.r))speed*=.52;
    movePlayer(p,dt,speed,map3Blocked);p.x=clamp(p.x,.5,M3.cols-.5);p.y=clamp(p.y,.5,M3.rows-.5);
  }
  if(!m.keyTaken){
    const finder=activeExplorers().find(p=>nearCell(p,M3.key,.72));
    if(finder){m.keyTaken=true;emitAll('toast',{text:`${finder.displayName||playerLabel(finder.id-1)} đã lấy chiếc chìa khóa cuối cùng!`,kind:'good'});}
  }
  const targetDoor=m.leverOn.every(Boolean)?1:0;
  m.keyDoorProgress+=((targetDoor)-m.keyDoorProgress)*Math.min(1,dt*5);
  m.keyDoorOpen=m.keyDoorProgress>.82;
  for(const g of m.golems)if(updateSmartGolem(g,dt))return;
  if(m.chestOpen){m.chestProgress=Math.min(1,m.chestProgress+dt*1.1);if(m.chestProgress>=1){game.phase='done';emitAll('win',{time:game.totalElapsed});}}
}

function consumeActions() {
  game.players.forEach((p, i) => {
    const actions = p.actions.splice(0);
    if(!p.active)return;
    for (const action of actions) {
      if (action === 'cheat') {
        if (!ALLOW_CHEAT) { emitTo(i+1,'toast',{text:'Chế độ thử nghiệm đã bị tắt trên máy chủ.',kind:'bad'}); continue; }
        game.cheat = !game.cheat;
        emitAll('toast', { text: `CHEAT XUYÊN VẬT THỂ: ${game.cheat ? 'BẬT' : 'TẮT'}`, kind: game.cheat ? 'good' : 'bad' });
        continue;
      }
      if (game.phase !== 'playing') continue;
      if (game.stage === 2 && action === 'pass') handleMap2Pass(i);
      if (game.stage === 3) {
        if (action === 'interact') handleMap3Interact(i);
        if (i === 0) processMap3CommanderAction(action);
      }
    }
  });
}



function applyInputMessage(player,message){
  const seq=Math.max(0,Number(message.seq)||0);
  if(seq&&seq<=player.lastInputSeq)return;
  if(seq)player.lastInputSeq=seq;
  player.lastInputAt=now();player.lastSeen=now();player.connected=true;
  if(message.input){
    const incoming={up:!!message.input.up,down:!!message.input.down,left:!!message.input.left,right:!!message.input.right};
    const any=incoming.up||incoming.down||incoming.left||incoming.right;
    if(player.needsNeutral){player.input={up:false,down:false,left:false,right:false};if(!any)player.needsNeutral=false;}else player.input=incoming;
  }
  if(Array.isArray(message.actions))for(const action of message.actions.slice(0,8))queueOrHandleAction(player,String(action));
}
function applyActionMessage(player,message){
  const seq=Math.max(0,Number(message.aseq??message.seq)||0);
  if(seq&&seq<=(player.lastActionSeq||0))return;
  if(seq)player.lastActionSeq=seq;
  player.lastInputAt=now();player.lastSeen=now();player.connected=true;
  const action=String(message.action||'');
  if(['pass','interact','mark','danger','clear','cheat'].includes(action))queueOrHandleAction(player,action);
}
function tickGame(g,dt,run=true){
  useGame(g);
  if(game.timerStarted==null)game.timerStarted=game.stage>1||game.phase==='playing'||game.totalElapsed>0;
  if(!run){game.revision++;return game;}
  const t = now(); dt = Math.min(.05, Math.max(0, Number(dt)||0));
  for (const p of game.players) if (p.lastInputAt && t - p.lastInputAt > 1300) { p.input={up:false,down:false,left:false,right:false}; p.vx=0; p.vy=0; }
  if(game.timerStarted&&!['done','lobby'].includes(game.phase))game.totalElapsed+=dt;
  if (game.phase === 'lobby') {
    // Server điều phối thời điểm bắt đầu để chốt đúng đội hình 3/3 hoặc 4/4 đang online.
  } else if (game.phase === 'briefing') {
    game.countdown = Math.max(0, game.countdown - dt);
    if(game.countdown<=0){resetPlayerMotion();game.phase='playing';if(game.stage===1)game.timerStarted=true;}
  } else if (game.phase === 'countdown') {
    game.countdown -= dt;
    if (game.countdown <= 0) { game.phase = 'playing'; if(game.stage===1)game.timerStarted=true; }
  } else if (game.phase === 'resetting') {
    game.countdown -= dt;
    if (game.stage === 2 && game.map2 && game.map2.caughtTimer > 0) {
      game.map2.caughtTimer -= dt;
      if (game.map2.caughtTimer <= 0) {
        resetMap2Positions();
        game.phase = 'countdown'; game.countdown = 2.8;
      }
    } else if (game.countdown <= 0) {
      if (game.stage === 1) setupMap1(game.map1?.puzzleIndex || 0);
      if (game.stage === 3) resetMap3Positions();
      game.phase = 'countdown'; game.countdown = 2.8;
    }
  } else if (game.phase === 'transition') {
    game.transitionTimer -= dt;
    if (game.transitionTimer <= 0) startStage(game.transitionTo);
  } else if (game.phase === 'playing') {
    game.elapsed += dt;
    consumeActions();
    if (game.stage === 1) updateMap1(dt);
    else if (game.stage === 2) updateMap2(dt);
    else if (game.stage === 3) updateMap3(dt);
  }
  game.revision++;
  return game;
}
function getPublicState(g,playerId=1,includeStatic=true,options={}){
  useGame(g);
  const observer=!!options.observer;
  const safeId=clamp(Number(playerId)||1,1,4);
  const ev=observer?[]:game.events[safeId-1].splice(0);
  const q=(v,d=2)=>Number.isFinite(Number(v))?Number(Number(v).toFixed(d)):v;
  const compactEntity=(v,d=2)=>{const o={...v};for(const k of ['x','y','vx','vy','homeX','homeY','baseY','anim','t','duration','r','phase'])if(k in o)o[k]=q(o[k],d);return o};
  let map1=null,map2=null,map3=null;
  if(game.stage===1&&game.map1){
    const {cats,...dynamic}=game.map1;
    map1={...dynamic,...(includeStatic?{cats:cats.map(c=>compactEntity(c,1))}:{})};
  }
  if(game.stage===2&&game.map2){
    const {muds,golems,ballPass,...dynamic}=game.map2;
    map2={...dynamic,doorProgress:q(dynamic.doorProgress,3),caughtTimer:q(dynamic.caughtTimer,3),ballPass:ballPass?{...ballPass,t:q(ballPass.t,3),duration:q(ballPass.duration,3)}:null,golems:golems.map(v=>compactEntity(v,1)),ball:compactEntity(ballPosition(),1),...(includeStatic?{muds:muds.map(v=>compactEntity(v,1))}:{})};
  }
  if(game.stage===3&&game.map3){
    const {maze,leverCells,muds,golems,patrolPoints,...dynamic}=game.map3;
    map3={...dynamic,keyDoorProgress:q(dynamic.keyDoorProgress,3),chestProgress:q(dynamic.chestProgress,3),golems:golems.map(({path,targetCell,...v})=>compactEntity(v,3)),...(includeStatic?{maze,leverCells,muds:muds.map(v=>compactEntity(v,3))}:{})};
  }
  const pd=game.stage===3?3:1;
  return {
    stage:game.stage,phase:game.phase,countdown:q(game.countdown,2),elapsed:q(game.elapsed,2),totalElapsed:q(game.totalElapsed,2),transitionTo:game.transitionTo,transitionTimer:q(game.transitionTimer,2),cheat:game.cheat,revision:game.revision,message:game.message,serverTime:now(),
    connectedCount:connectedCount(),playerCount:activePlayerCount(),readyCount:activePlayers().filter(v=>v.connected&&now()-v.lastSeen<PLAYER_TIMEOUT&&v.ready).length,briefingReadyCount:briefingReadyCount(),briefingAcks:[...game.stageAcks],self:safeId,observer,
    team:options.team||null,event:options.event||null,
    players:game.players.map(({input,actions,lastSeen,needsNeutral,clientToken,lastInputSeq,lastActionSeq,lastInputAt,...v})=>({...compactEntity(v,pd),online:!!v.connected&&now()-lastSeen<PLAYER_TIMEOUT,ackSeq:lastInputSeq})),
    map1,map2,map3,events:ev,
  };
}
function setReady(g,id,value=true){useGame(g);const p=game.players[clamp(Number(id)-1,0,3)];if(!p.active)return false;p.ready=value!==false;p.connected=true;p.lastSeen=now();return true;}
function applyInput(g,id,message){useGame(g);const p=game.players[clamp(Number(id)-1,0,3)];if(!p.active)return false;applyInputMessage(p,message||{});return true;}
function applyAction(g,id,message){useGame(g);const p=game.players[clamp(Number(id)-1,0,3)];if(!p.active)return false;applyActionMessage(p,message||{});return true;}
function submitCode(g,raw){useGame(g);if(game.stage!==1||game.phase!=='playing'||!game.map1)return{ok:false,message:'Không ở tầng 1.'};const values=Array.isArray(raw)?raw:String(raw||'').split(',');const input=values.map(Number).filter(v=>Number.isInteger(v)&&v>=1&&v<=12).slice(0,4).sort((a,b)=>a-b);const answer=[...game.map1.specialHours].sort((a,b)=>a-b);const correct=input.length===4&&new Set(input).size===4&&input.every((v,i)=>v===answer[i]);if(correct){game.map1.solved=true;emitAll('toast',{text:'Mật mã chính xác. Cả đội chuyển sang tầng 2.',kind:'good'});beginTransition(2);return{ok:true};}const next=(game.map1.puzzleIndex+1)%MAP1.puzzles.length;game.map1.puzzleIndex=next;game.map1.specialHours=MAP1.puzzles[next];game.map1.cats=map1Cats(game.map1.specialHours);emitAll('toast',{text:'Sai mật mã. Bốn tượng khác biệt đã đổi vị trí.',kind:'bad'});return{ok:false,message:'Sai mật mã.'};}
function disconnectPlayer(g,id,token=''){useGame(g);const p=game.players[clamp(Number(id)-1,0,3)];if(!token||p.clientToken===token){p.connected=false;p.clientToken='';p.input={up:false,down:false,left:false,right:false};p.vx=0;p.vy=0;p.needsNeutral=true;}}
function setActivePlayers(g,names=[]){useGame(g);const list=Array.from({length:4},(_,i)=>String(names?.[i]||'').trim().slice(0,40));game.players.forEach((p,i)=>{p.active=!!list[i];p.displayName=list[i]||`Vị trí ${i+1}`;if(!p.active){p.connected=false;p.ready=false;p.clientToken='';p.input={up:false,down:false,left:false,right:false};p.actions.length=0;p.vx=0;p.vy=0;p.escaped=false;}});game.revision++;return activePlayerCount();}
function resetGame(g){useGame(g);resetLobby();return game;}
function forceStart(g,stage=1){useGame(g);if(activePlayerCount()<3)return false;startStage(clamp(Number(stage)||1,1,3));return game;}
function forceFinish(g){useGame(g);game.phase='done';game.finishedAt=Date.now();game.revision++;emitAll('win',{time:game.totalElapsed});return game;}
module.exports={createGame,useGame,setAllowCheat,setActivePlayers,tickGame,getPublicState,setReady,applyInput,applyAction,submitCode,disconnectPlayer,resetGame,forceStart,forceFinish,now,PLAYER_TIMEOUT};
