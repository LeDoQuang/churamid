@echo off
chcp 65001 >nul
set /p PAGE=Nhập URL GitHub Pages, ví dụ https://tenban.github.io/gameday-2026/: 
set /p TUNNEL=Nhập URL Cloudflare Tunnel, ví dụ https://abc.trycloudflare.com: 
if "%PAGE%"=="" (echo Thiếu URL GitHub Pages.& pause & exit /b 1)
if "%TUNNEL%"=="" (echo Thiếu URL Tunnel.& pause & exit /b 1)
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$p='%PAGE%'.TrimEnd('/')+'/';$t=[uri]::EscapeDataString('%TUNNEL%'.TrimEnd('/'));$p+'?server='+$t"`) do set LINK=%%A
echo.
echo LINK NGƯỜI CHƠI:
echo %LINK%
echo %LINK%| clip
echo.
echo Đã copy link vào clipboard.
pause
