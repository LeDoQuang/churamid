@echo off
chcp 65001 >nul
cd /d "%~dp0"
set /p ORIGIN=Nhap origin frontend (co the nhieu origin cach nhau boi dau phay): 
if "%ORIGIN%"=="" (echo Chua nhap origin.& pause & exit /b 1)
powershell -NoProfile -Command "$p='SETTINGS.bat';$s=Get-Content $p -Raw;if($s -match '(?m)^set ALLOWED_ORIGINS=.*$'){$s=[regex]::Replace($s,'(?m)^set ALLOWED_ORIGINS=.*$','set ALLOWED_ORIGINS=%ORIGIN%')}else{$s += [Environment]::NewLine+'set ALLOWED_ORIGINS=%ORIGIN%'+[Environment]::NewLine};Set-Content $p $s -Encoding ASCII"
echo Da luu ALLOWED_ORIGINS=%ORIGIN%
echo Vi du ten mien rieng: http://tenmien.vn,https://tenmien.vn
echo Khong them /ten-repo hoac duong dan vao origin.
pause
