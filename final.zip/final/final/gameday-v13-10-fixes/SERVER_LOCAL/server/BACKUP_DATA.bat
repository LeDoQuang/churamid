@echo off
chcp 65001 >nul
cd /d "%~dp0"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set TS=%%i
if not exist backups mkdir backups
powershell -NoProfile -Command "Compress-Archive -Path '.\data\*' -DestinationPath ('.\backups\gameday-data-%TS%.zip') -Force"
echo Da sao luu vao server\backups\gameday-data-%TS%.zip
pause
