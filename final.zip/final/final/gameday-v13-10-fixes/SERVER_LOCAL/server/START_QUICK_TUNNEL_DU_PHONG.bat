@echo off
chcp 65001 >nul
cd /d "%~dp0"
call SETTINGS.bat
title IDEA GAMEDAY 2026 - CLOUDFLARE TUNNEL
where cloudflared >nul 2>nul || (echo Chua tim thay cloudflared trong PATH.& pause & exit /b 1)

echo Dang kiem tra server tai http://127.0.0.1:%PORT%/health ...
set READY=0
for /l %%I in (1,1,8) do (
  powershell -NoProfile -Command "try{$r=Invoke-RestMethod 'http://127.0.0.1:%PORT%/health' -TimeoutSec 2;if($r.ok){exit 0}else{exit 1}}catch{exit 1}"
  if not errorlevel 1 set READY=1
  if not errorlevel 1 goto :server_ready
  timeout /t 1 /nobreak >nul
)

if "%READY%"=="0" (
  echo Server game chua phan hoi tai http://127.0.0.1:%PORT%/health
  echo Hay giu START_SERVER_EVENT.bat mo va thu lai.
  pause
  exit /b 1
)

:server_ready
echo Server da san sang.
echo Tao Cloudflare Quick Tunnel toi http://127.0.0.1:%PORT% ...
echo Copy URL https://...trycloudflare.com hien ben duoi.
cloudflared tunnel --url http://127.0.0.1:%PORT%
pause
