@echo off
chcp 65001 >nul
echo === DNS DOMAIN ===
nslookup churamidgameday2026.me 1.1.1.1
echo.
echo === DNS SERVER HOSTNAME ===
nslookup server.churamidgameday2026.me 1.1.1.1
echo.
echo === HEALTH ===
powershell -NoProfile -Command "try{Invoke-RestMethod 'https://server.churamidgameday2026.me/health' -TimeoutSec 10|ConvertTo-Json -Compress}catch{Write-Host $_.Exception.Message}"
pause
