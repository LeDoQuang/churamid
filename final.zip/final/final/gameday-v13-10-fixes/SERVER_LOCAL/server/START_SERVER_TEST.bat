@echo off
chcp 65001 >nul
cd /d "%~dp0"
call SETTINGS.bat
set ALLOW_CHEAT=1
title IDEA GAMEDAY 2026 - TEST SERVER
where node >nul 2>nul || (echo Chua tim thay Node.js. Hay cai Node.js 20 tro len.& pause & exit /b 1)
powershell -NoProfile -Command "if(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue){exit 1}else{exit 0}"
if errorlevel 1 (echo Cong %PORT% dang duoc mot chuong trinh khac su dung. Hay dong server cu truoc.& pause & exit /b 1)
echo Dang khoi dong che do thu nghiem tai cong %PORT%...
node server.js
pause
