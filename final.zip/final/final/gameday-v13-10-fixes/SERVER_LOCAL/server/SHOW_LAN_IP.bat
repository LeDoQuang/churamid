@echo off
chcp 65001 >nul
cd /d "%~dp0"
call SETTINGS.bat
echo.
echo Dia chi de cac may cung Wi-Fi/LAN truy cap:
powershell -NoProfile -Command "$ips=Get-NetIPAddress -AddressFamily IPv4 ^| Where-Object {$_.IPAddress -notlike '169.254*' -and $_.IPAddress -ne '127.0.0.1'} ^| Select-Object -ExpandProperty IPAddress; $ips ^| ForEach-Object {Write-Host ('  http://' + $_ + ':%PORT%/')}"
echo.
echo Uu tien dung LAN trong ngay su kien de giam do tre va tai Internet.
pause
