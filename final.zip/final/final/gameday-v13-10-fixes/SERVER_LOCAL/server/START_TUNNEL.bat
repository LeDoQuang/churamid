@echo off
chcp 65001 >nul
cd /d "%~dp0"
call SETTINGS.bat
title RUNNING CVA - NAMED TUNNEL

echo Dang kiem tra Node server tai http://127.0.0.1:%PORT%/health ...
powershell -NoProfile -Command "try{$r=Invoke-RestMethod 'http://127.0.0.1:%PORT%/health' -TimeoutSec 3;if(-not $r.ok){exit 1}}catch{exit 1}"
if errorlevel 1 (
  echo Node server chua san sang. Hay chay START_SERVER_EVENT.bat truoc.
  pause
  exit /b 1
)

echo Dang kiem tra Windows service cloudflared ...
sc query cloudflared | findstr /I "RUNNING" >nul
if errorlevel 1 (
  echo Named Tunnel chua chay hoac chua duoc cai thanh service.
  echo Hay vao Cloudflare Tunnels, chay lenh service install co token.
  echo Xem file HUONG_DAN_NAMED_TUNNEL.txt o thu muc goc.
  pause
  exit /b 1
)

echo Named Tunnel dang chay.
echo Link co dinh: https://server.churamidgameday2026.me
powershell -NoProfile -Command "try{$r=Invoke-RestMethod 'https://server.churamidgameday2026.me/health' -TimeoutSec 10;Write-Host ('Health: '+($r|ConvertTo-Json -Compress))}catch{Write-Host 'Hostname chua san sang. Domain co the dang cho Active hoac route chua duoc tao.'}"
pause
