@echo off
cd /d "%~dp0"
start "GAMEDAY SERVER" cmd /k "server\START_SERVER_TEST.bat"
timeout /t 2 /nobreak >nul
call server\OPEN_ADMIN.bat
call server\OPEN_LOGIN_LOCAL.bat
