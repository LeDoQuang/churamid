# Checklist ngày tổ chức

## Trước 1–2 ngày

- [ ] Đổi `ADMIN_PASSWORD` trong `server/SETTINGS.bat`.
- [ ] Nhập đủ danh sách đội và kiểm tra tên người chơi không trùng.
- [ ] Chạy `CHECK_PROJECT.bat`.
- [ ] Test một lượt đầy đủ với 4 điện thoại và 1 máy quan sát.
- [ ] Test tạm dừng, tiếp tục, reset một đội và xuất CSV.
- [ ] Sao lưu thư mục `server/data`.

## Trước giờ bắt đầu

- [ ] Cắm dây LAN cho máy chủ.
- [ ] Cắm sạc và tắt Sleep/Hibernate trên máy chủ.
- [ ] Chạy `START_SERVER_EVENT.bat`, không dùng bản TEST.
- [ ] Cho Windows Firewall quyền mạng Private.
- [ ] Mở `/health`, `/admin` và `/scoreboard`.
- [ ] Để sự kiện ở trạng thái **Mở phòng chờ**.
- [ ] Kiểm tra số đội online và đủ 4/4 trước khi bắt đầu.

## Trong sự kiện

- [ ] Không tắt cửa sổ Node.js.
- [ ] Theo dõi RAM, độ trễ server và số WebSocket trên trang admin.
- [ ] Khi mạng hoặc luật chơi có sự cố, bấm **Tạm dừng** trước.
- [ ] Chỉ reset đúng đội gặp lỗi.
- [ ] Không chỉnh trực tiếp file trong `server/data`.

## Sau sự kiện

- [ ] Bấm **Kết thúc**.
- [ ] Xuất kết quả CSV.
- [ ] Tải nhật ký thao tác.
- [ ] Chạy `BACKUP_DATA.bat`.
- [ ] Chỉ sau khi sao lưu mới đóng server.
