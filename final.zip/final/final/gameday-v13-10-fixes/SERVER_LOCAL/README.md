# IDEA GAMEDAY 2026 — Event Server V13.6

## Cần cài

- Node.js 20 trở lên.
- `cloudflared` khi chơi qua Internet.
- Không cần MySQL, XAMPP hay `npm install`.

## Chạy

Test:

```text
server\START_SERVER_TEST.bat
```

Chính thức:

```text
server\START_SERVER_EVENT.bat
server\START_TUNNEL.bat
```

Địa chỉ local:

- Người chơi: `http://localhost:3000/`
- Admin: `http://localhost:3000/admin`
- Bảng xếp hạng: `http://localhost:3000/scoreboard`
- Health: `http://localhost:3000/health`

## Đăng nhập

Mỗi đội có:

- Mã đội chơi.
- Mật khẩu.
- Mã quan sát.

Người chơi tự nhập tên. Người vào đầu tiên nhận vai trò 1, sau đó 2, 3 và 4. Mã quan sát được nhập vào cùng ô mã đội và mở đúng phòng ở chế độ chỉ xem.

Tài khoản demo được tạo trong lần chạy đầu:

```text
Mã đội: demo
Mật khẩu: demo123
Mã quan sát: watch-demo
```

## Điều hành sự kiện

- **Mở phòng chờ:** cho đội đăng nhập nhưng chưa thể sẵn sàng.
- **Mở sẵn sàng:** đội có 3 hoặc 4 thành viên tự bắt đầu khi tất cả thành viên trong phòng nhấn Sẵn sàng.
- **Bắt đầu ngay đội đủ 3:** bắt đầu ngay mọi đội có ít nhất 3 người online; người đã đăng ký nhưng đang ngoại tuyến được loại khỏi đội trước khi bắt đầu.
- **Bắt đầu đội:** thực hiện tương tự nhưng chỉ cho một đội.
- Có thể tạm dừng, tiếp tục, kết thúc, reset, chốt hoàn thành, quan sát và xóa từng người chơi.

Chỉ có bước Sẵn sàng ở phòng chờ. Mỗi tầng tự hiển thị luật và đếm ngược; nút `?` mở lại luật trong lúc chơi.

## Mất mạng và vào lại

- Dùng đúng mã đội, mật khẩu và đúng tên đã nhập trước đó.
- Người chơi nhận lại vai trò cũ; phiên cũ bị thay thế.
- Phòng đang chơi tạm giữ sau 5 giây thiếu người.
- Khi tối thiểu 3 thành viên trở lại, phòng tiếp tục sau 3 giây.
- Ở phòng chờ, admin có thể xóa từng người bị kẹt; vai trò còn lại tự dồn lại.

## Dữ liệu

```text
server\data\event.json
server\data\runtime.json
server\data\audit.log
```

Bản ZIP không kèm các tệp trên để tránh ghi đè dữ liệu. Chạy `BACKUP_DATA.bat` trước khi cập nhật hoặc trước sự kiện.

## GitHub Pages và CORS

Chỉ up `GITHUB_REPO/docs`. Trong `SETTINGS.bat`, thêm origin frontend vào `ALLOWED_ORIGINS`, ví dụ:

```bat
set ALLOWED_ORIGINS=http://churamidgameday2026.me,https://churamidgameday2026.me
```

Không thêm đường dẫn `/gd_demo/`.

## Ngày chạy chính thức

- Đổi `ADMIN_PASSWORD` trong `SETTINGS.bat`.
- Dùng `START_SERVER_EVENT.bat`, không dùng bản test.
- Tắt Sleep của Windows.
- Giữ Node.js và cloudflared mở.
- Kiểm tra `/health` cả local lẫn Cloudflare.
- Sao lưu dữ liệu sau sự kiện.
