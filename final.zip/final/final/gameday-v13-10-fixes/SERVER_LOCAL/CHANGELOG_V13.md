# V13 — Multi-team Event Server

- Tách mỗi đội thành một phòng game độc lập.
- Thêm đăng nhập tài khoản đội, mật khẩu và tên người chơi.
- Thay P1–P4 bằng tên thật đã khai báo.
- Chặn một vị trí người chơi bị chiếm đồng thời bởi hai thiết bị.
- Thêm người quan sát chỉ xem và đổi góc nhìn.
- Thêm trang quản trị chỉ mở tại máy chủ theo mặc định.
- Thêm tạo, sửa, khóa, mở khóa, xóa và nhập đội bằng CSV.
- Thêm bắt đầu, tạm dừng, tiếp tục, kết thúc và reset sự kiện.
- Thêm reset, bắt đầu riêng và chốt hoàn thành từng đội.
- Thêm thời gian hoàn thành, tình trạng đội, số người online và sẵn sàng.
- Thêm bảng xếp hạng trực tiếp và xuất kết quả CSV.
- Thêm nhật ký quản trị/đăng nhập và script sao lưu dữ liệu.
- Mật khẩu đội được băm bằng scrypt; xác thực chạy bất đồng bộ để tránh khóa game loop khi nhiều đội đăng nhập cùng lúc.
- Thêm giới hạn đăng nhập, session ngẫu nhiên, kiểm tra Origin WebSocket và heartbeat ping/pong.
- Lưu tiến độ định kỳ bằng ghi file bất đồng bộ.
- Thêm số liệu RAM, WebSocket và event-loop lag trên trang quản trị.
- Thêm bộ script Windows cho test, sự kiện, LAN, Cloudflare Tunnel và kiểm tra dự án.
