BAN DA DUOC CAU HINH SAN CHO TEN MIEN CO DINH

Frontend: https://churamidgameday2026.me
API/WebSocket: https://server.churamidgameday2026.me

DA DOI SAN:
- docs/CNAME
- docs/client-config.js
- SETTINGS.bat ALLOWED_ORIGINS
- cache version 13.9
- START_TUNNEL.bat thanh cong cu kiem tra Named Tunnel
- giu START_QUICK_TUNNEL_DU_PHONG.bat de du phong

THU TU:
1. Cho Cloudflare domain Active.
2. Cai Named Tunnel theo HUONG_DAN_NAMED_TUNNEL.txt.
3. Upload GITHUB_REPO len GitHub.
4. Chay START_SERVER_EVENT.bat.
5. Kiem tra /health.
