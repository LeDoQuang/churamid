# V13.9 domain-ready

- Gộp đầy đủ V13.7 và cập nhật đăng nhập ẩn mã quan sát V13.8.
- Thêm `docs/CNAME` cho `churamidgameday2026.me`.
- Frontend GitHub mặc định kết nối `https://server.churamidgameday2026.me`.
- Local frontend tiếp tục dùng cùng origin để admin và test localhost hoạt động.
- Cấu hình sẵn `ALLOWED_ORIGINS` cho domain gốc, `www` và GitHub Pages dự phòng.
- Đổi `START_TUNNEL.bat` thành kiểm tra Named Tunnel; giữ Quick Tunnel dưới tên dự phòng.
- Tăng cache version lên 13.9.
- Không đóng gói thư mục dữ liệu runtime để không ghi đè danh sách đội khi cập nhật.
